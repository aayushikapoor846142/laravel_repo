<?php

/**
 * Test script for chunked upload functionality
 * Run with: php test_chunked_upload.php
 */

$baseUrl = 'http://localhost:8000';

// Create a test image file
$testImagePath = __DIR__ . '/test_image.jpg';
if (!file_exists($testImagePath)) {
    echo "Creating test image...\n";
    $image = imagecreatetruecolor(800, 600);
    $bgColor = imagecolorallocate($image, 100, 150, 200);
    imagefill($image, 0, 0, $bgColor);
    
    // Add some text
    $textColor = imagecolorallocate($image, 255, 255, 255);
    imagestring($image, 5, 300, 280, 'Test Image', $textColor);
    
    imagejpeg($image, $testImagePath, 90);
    imagedestroy($image);
    echo "Test image created: $testImagePath\n\n";
}

// Read file
$fileContent = file_get_contents($testImagePath);
$fileSize = filesize($testImagePath);
$checksum = hash('sha256', $fileContent);

echo "File size: " . number_format($fileSize) . " bytes\n";
echo "Checksum: $checksum\n\n";

// Split into chunks
$chunkSize = 50000; // 50KB chunks
$totalChunks = ceil($fileSize / $chunkSize);
$chunks = [];

for ($i = 0; $i < $totalChunks; $i++) {
    $offset = $i * $chunkSize;
    $length = min($chunkSize, $fileSize - $offset);
    $chunks[] = base64_encode(substr($fileContent, $offset, $length));
}

echo "Split into $totalChunks chunks\n\n";

// Step 1: Initialize upload
echo "Step 1: Initializing upload...\n";
$initData = [
    'filename' => 'test_image.jpg',
    'mime_type' => 'image/jpeg',
    'total_size' => $fileSize,
    'total_chunks' => $totalChunks,
    'checksum' => $checksum,
];

$ch = curl_init("$baseUrl/api/uploads/initialize");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($initData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 201) {
    die("Failed to initialize upload. HTTP $httpCode\nResponse: $response\n");
}

$initResult = json_decode($response, true);
$uploadId = $initResult['upload_id'];
echo "Upload initialized. ID: $uploadId\n\n";

// Step 2: Upload chunks
echo "Step 2: Uploading chunks...\n";
foreach ($chunks as $index => $chunkData) {
    echo "Uploading chunk " . ($index + 1) . "/$totalChunks... ";
    
    $chunkPayload = [
        'chunk_index' => $index,
        'chunk_data' => $chunkData,
    ];
    
    $ch = curl_init("$baseUrl/api/uploads/$uploadId/chunk");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($chunkPayload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        die("Failed. HTTP $httpCode\nResponse: $response\n");
    }
    
    $chunkResult = json_decode($response, true);
    echo "OK ({$chunkResult['progress']}%)\n";
}

echo "\n";

// Step 3: Complete upload
echo "Step 3: Completing upload...\n";
$ch = curl_init("$baseUrl/api/uploads/$uploadId/complete");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    die("Failed to complete upload. HTTP $httpCode\nResponse: $response\n");
}

echo "Upload completed successfully!\n\n";

// Step 4: Check status
echo "Step 4: Checking status...\n";
$ch = curl_init("$baseUrl/api/uploads/$uploadId/status");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$status = json_decode($response, true);
echo "Status: {$status['status']}\n";
echo "Progress: {$status['progress']}%\n\n";

echo "✓ All steps completed successfully!\n";
echo "\nTo attach to a product, run:\n";
echo "curl -X POST $baseUrl/api/uploads/$uploadId/attach-product \\\n";
echo "  -H 'Content-Type: application/json' \\\n";
echo "  -d '{\"product_id\": 1, \"set_as_primary\": true}'\n";
