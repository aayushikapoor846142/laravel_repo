<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductImportController;
use App\Http\Controllers\ChunkedUploadController;
use App\Http\Controllers\ProductManagementController;

// Test route
Route::get('/test', function () {
    return 'Laravel is working!';
});

// UI Routes
Route::get('/', [ProductManagementController::class, 'index'])->name('products.index');
Route::get('/products', [ProductManagementController::class, 'index'])->name('products.list'); // Alias
Route::get('/products/import', [ProductManagementController::class, 'import'])->name('products.import');
Route::get('/products/upload', [ProductManagementController::class, 'upload'])->name('products.upload');
Route::get('/products/{product}', [ProductManagementController::class, 'show'])->name('products.show');

// API Routes - Product Import
Route::post('/api/products/import', [ProductImportController::class, 'import'])->name('api.products.import');

// API Routes - Chunked Upload
Route::prefix('api/uploads')->group(function () {
    Route::post('/initialize', [ChunkedUploadController::class, 'initialize'])->name('api.uploads.initialize');
    Route::post('/{upload}/chunk', [ChunkedUploadController::class, 'uploadChunk'])->name('api.uploads.chunk');
    Route::post('/{upload}/complete', [ChunkedUploadController::class, 'complete'])->name('api.uploads.complete');
    Route::get('/{upload}/status', [ChunkedUploadController::class, 'status'])->name('api.uploads.status');
    Route::post('/{upload}/attach-product', [ChunkedUploadController::class, 'attachToProduct'])->name('api.uploads.attach');
});