<?php

$url = 'http://localhost:8000/';

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

echo "HTTP Code: $httpCode\n";
echo "Response Length: " . strlen($response) . " bytes\n\n";

if (strlen($response) > 0) {
    echo "Full Response:\n";
    echo $response;
} else {
    echo "Response is empty!\n";
    echo "\nPossible issues:\n";
    echo "1. Server not running - run: php artisan serve\n";
    echo "2. View rendering error\n";
    echo "3. Check storage/logs/laravel.log for errors\n";
}
