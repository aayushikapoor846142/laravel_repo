<?php

namespace App\Services;

use App\Models\Image;
use App\Models\Upload;
use Illuminate\Support\Facades\Storage;

/**
 * Alternative ImageVariantService using PHP GD (no external dependencies)
 * Use this if Intervention Image is not installed
 */
class ImageVariantServiceGD
{
    private array $variants = [256, 512, 1024];

    public function generateVariants(Upload $upload, $imageable): array
    {
        if (!$upload->isComplete()) {
            throw new \RuntimeException('Upload not completed');
        }

        $sourcePath = Storage::disk('public')->path($upload->filename);
        
        if (!file_exists($sourcePath)) {
            throw new \RuntimeException('Source file not found');
        }

        $images = [];
        
        // Get image info
        $imageInfo = getimagesize($sourcePath);
        if ($imageInfo === false) {
            throw new \RuntimeException('Invalid image file');
        }

        // Create original image record
        $originalImage = Image::create([
            'upload_id' => $upload->id,
            'imageable_type' => get_class($imageable),
            'imageable_id' => $imageable->id,
            'variant' => 'original',
            'path' => $upload->filename,
            'width' => $imageInfo[0],
            'height' => $imageInfo[1],
            'size' => filesize($sourcePath),
            'is_primary' => false,
        ]);

        $images[] = $originalImage;

        // Load source image
        $sourceImage = $this->loadImage($sourcePath, $imageInfo[2]);
        if (!$sourceImage) {
            throw new \RuntimeException('Failed to load image');
        }

        // Generate variants
        foreach ($this->variants as $maxSize) {
            try {
                $variantImage = $this->createVariant(
                    $upload, 
                    $imageable, 
                    $sourceImage, 
                    $imageInfo[0], 
                    $imageInfo[1], 
                    $maxSize,
                    $imageInfo[2]
                );
                $images[] = $variantImage;
            } catch (\Exception $e) {
                \Log::error("Failed to create {$maxSize}px variant: " . $e->getMessage());
            }
        }

        imagedestroy($sourceImage);

        return $images;
    }

    private function loadImage(string $path, int $type)
    {
        return match ($type) {
            IMAGETYPE_JPEG => imagecreatefromjpeg($path),
            IMAGETYPE_PNG => imagecreatefrompng($path),
            IMAGETYPE_GIF => imagecreatefromgif($path),
            IMAGETYPE_WEBP => imagecreatefromwebp($path),
            default => false,
        };
    }

    private function createVariant(
        Upload $upload, 
        $imageable, 
        $sourceImage, 
        int $originalWidth, 
        int $originalHeight, 
        int $maxSize,
        int $imageType
    ): Image {
        // Calculate new dimensions maintaining aspect ratio
        if ($originalWidth > $originalHeight) {
            $newWidth = min($originalWidth, $maxSize);
            $newHeight = (int) round(($originalHeight / $originalWidth) * $newWidth);
        } else {
            $newHeight = min($originalHeight, $maxSize);
            $newWidth = (int) round(($originalWidth / $originalHeight) * $newHeight);
        }

        // Create resized image
        $resizedImage = imagecreatetruecolor($newWidth, $newHeight);
        
        // Preserve transparency for PNG and GIF
        if ($imageType === IMAGETYPE_PNG || $imageType === IMAGETYPE_GIF) {
            imagealphablending($resizedImage, false);
            imagesavealpha($resizedImage, true);
            $transparent = imagecolorallocatealpha($resizedImage, 255, 255, 255, 127);
            imagefilledrectangle($resizedImage, 0, 0, $newWidth, $newHeight, $transparent);
        }

        // Resize
        imagecopyresampled(
            $resizedImage, 
            $sourceImage, 
            0, 0, 0, 0, 
            $newWidth, 
            $newHeight, 
            $originalWidth, 
            $originalHeight
        );

        // Generate variant filename
        $pathInfo = pathinfo($upload->filename);
        $variantFilename = $pathInfo['dirname'] . '/' . 
                          $pathInfo['filename'] . "_{$maxSize}px." . 
                          $pathInfo['extension'];

        // Save variant
        $variantPath = Storage::disk('public')->path($variantFilename);
        
        $saved = match ($imageType) {
            IMAGETYPE_JPEG => imagejpeg($resizedImage, $variantPath, 90),
            IMAGETYPE_PNG => imagepng($resizedImage, $variantPath, 9),
            IMAGETYPE_GIF => imagegif($resizedImage, $variantPath),
            IMAGETYPE_WEBP => imagewebp($resizedImage, $variantPath, 90),
            default => false,
        };

        imagedestroy($resizedImage);

        if (!$saved) {
            throw new \RuntimeException("Failed to save variant");
        }

        return Image::create([
            'upload_id' => $upload->id,
            'imageable_type' => get_class($imageable),
            'imageable_id' => $imageable->id,
            'variant' => "{$maxSize}px",
            'path' => $variantFilename,
            'width' => $newWidth,
            'height' => $newHeight,
            'size' => filesize($variantPath),
            'is_primary' => false,
        ]);
    }

    public function setPrimaryImage($imageable, Image $image): void
    {
        // Check if same image is already primary (idempotent)
        if ($image->is_primary && $imageable->primary_image_id === $image->id) {
            return;
        }

        \DB::transaction(function () use ($imageable, $image) {
            // Remove primary flag from all images
            Image::where('imageable_type', get_class($imageable))
                ->where('imageable_id', $imageable->id)
                ->update(['is_primary' => false]);

            // Set new primary
            $image->update(['is_primary' => true]);
            $imageable->update(['primary_image_id' => $image->id]);
        });
    }

    public function attachUploadToEntity(Upload $upload, $entity): array
    {
        // Check if upload already attached to this entity (idempotent)
        $existingImages = Image::where('upload_id', $upload->id)
            ->where('imageable_type', get_class($entity))
            ->where('imageable_id', $entity->id)
            ->exists();

        if ($existingImages) {
            return Image::where('upload_id', $upload->id)
                ->where('imageable_type', get_class($entity))
                ->where('imageable_id', $entity->id)
                ->get()
                ->toArray();
        }

        // Link upload to entity
        $upload->update([
            'uploadable_type' => get_class($entity),
            'uploadable_id' => $entity->id,
        ]);

        return $this->generateVariants($upload, $entity);
    }
}
