<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ProductImportService
{
    private array $results = [
        'total' => 0,
        'imported' => 0,
        'updated' => 0,
        'invalid' => 0,
        'duplicates' => 0,
    ];

    private array $seenSkus = [];

    public function importFromCsv(string $filePath): array
    {
        if (!file_exists($filePath)) {
            throw new \InvalidArgumentException("File not found: {$filePath}");
        }

        $handle = fopen($filePath, 'r');
        if ($handle === false) {
            throw new \RuntimeException("Unable to open file: {$filePath}");
        }

        $headers = fgetcsv($handle);
        if ($headers === false) {
            fclose($handle);
            throw new \RuntimeException("Unable to read CSV headers");
        }

        $headers = array_map('trim', $headers);
        $requiredColumns = ['sku', 'name', 'price'];

        while (($row = fgetcsv($handle)) !== false) {
            $this->results['total']++;
            $data = array_combine($headers, $row);
            
            if ($data === false || !$this->hasRequiredColumns($data, $requiredColumns)) {
                $this->results['invalid']++;
                continue;
            }

            $this->processRow($data);
        }

        fclose($handle);
        return $this->results;
    }

    private function hasRequiredColumns(array $data, array $required): bool
    {
        foreach ($required as $column) {
            if (!isset($data[$column]) || trim($data[$column]) === '') {
                return false;
            }
        }
        return true;
    }

    private function processRow(array $data): void
    {
        $sku = trim($data['sku']);

        // Check for duplicates within the CSV
        if (isset($this->seenSkus[$sku])) {
            $this->results['duplicates']++;
            return;
        }

        $validator = Validator::make($data, [
            'sku' => 'required|string|max:255',
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'stock' => 'nullable|integer|min:0',
        ]);

        if ($validator->fails()) {
            $this->results['invalid']++;
            return;
        }

        $this->seenSkus[$sku] = true;

        try {
            DB::transaction(function () use ($data, $sku) {
                $existing = Product::where('sku', $sku)->lockForUpdate()->first();

                $productData = [
                    'sku' => $sku,
                    'name' => trim($data['name']),
                    'description' => isset($data['description']) ? trim($data['description']) : null,
                    'price' => (float) $data['price'],
                    'stock' => isset($data['stock']) ? (int) $data['stock'] : 0,
                ];

                if ($existing) {
                    $existing->update($productData);
                    $this->results['updated']++;
                } else {
                    Product::create($productData);
                    $this->results['imported']++;
                }
            });
        } catch (\Exception $e) {
            $this->results['invalid']++;
        }
    }

    public function getResults(): array
    {
        return $this->results;
    }
}
