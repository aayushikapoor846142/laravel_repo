<?php

namespace App\Services;

use App\Models\Image;
use App\Models\Upload;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class ImageVariantService
{
    private array $variants = [256, 512, 1024];
    private ImageManager $manager;

    public function __construct()
    {
        $this->manager = new ImageManager(new Driver());
    }

    public function generateVariants(Upload $upload, $imageable): array
    {
        if (!$upload->isComplete()) {
            throw new \RuntimeException('Upload not completed');
        }

        $sourcePath = Storage::disk('public')->path($upload->filename);
        
        if (!file_exists($sourcePath)) {
            throw new \RuntimeException('Source file not found');
        }

        $images = [];
        
        // Create original image record
        $imageInfo = getimagesize($sourcePath);
        if ($imageInfo === false) {
            throw new \RuntimeException('Invalid image file');
        }

        $originalImage = Image::create([
            'upload_id' => $upload->id,
            'imageable_type' => get_class($imageable),
            'imageable_id' => $imageable->id,
            'variant' => 'original',
            'path' => $upload->filename,
            'width' => $imageInfo[0],
            'height' => $imageInfo[1],
            'size' => filesize($sourcePath),
            'is_primary' => false,
        ]);

        $images[] = $originalImage;

        // Generate variants
        foreach ($this->variants as $maxSize) {
            try {
                $variantImage = $this->createVariant($upload, $imageable, $sourcePath, $maxSize);
                $images[] = $variantImage;
            } catch (\Exception $e) {
                // Log error but continue with other variants
                \Log::error("Failed to create {$maxSize}px variant: " . $e->getMessage());
            }
        }

        return $images;
    }

    private function createVariant(Upload $upload, $imageable, string $sourcePath, int $maxSize): Image
    {
        $image = $this->manager->read($sourcePath);
        
        // Calculate new dimensions maintaining aspect ratio
        $width = $image->width();
        $height = $image->height();
        
        if ($width > $height) {
            $newWidth = min($width, $maxSize);
            $newHeight = (int) round(($height / $width) * $newWidth);
        } else {
            $newHeight = min($height, $maxSize);
            $newWidth = (int) round(($width / $height) * $newHeight);
        }

        // Resize maintaining aspect ratio
        $image->scale($newWidth, $newHeight);

        // Generate variant filename
        $pathInfo = pathinfo($upload->filename);
        $variantFilename = $pathInfo['dirname'] . '/' . 
                          $pathInfo['filename'] . "_{$maxSize}px." . 
                          $pathInfo['extension'];

        // Save variant
        $variantPath = Storage::disk('public')->path($variantFilename);
        $image->save($variantPath);

        return Image::create([
            'upload_id' => $upload->id,
            'imageable_type' => get_class($imageable),
            'imageable_id' => $imageable->id,
            'variant' => "{$maxSize}px",
            'path' => $variantFilename,
            'width' => $newWidth,
            'height' => $newHeight,
            'size' => filesize($variantPath),
            'is_primary' => false,
        ]);
    }

    public function setPrimaryImage($imageable, Image $image): void
    {
        // Check if same image is already primary (idempotent)
        if ($image->is_primary && $imageable->primary_image_id === $image->id) {
            return;
        }

        \DB::transaction(function () use ($imageable, $image) {
            // Remove primary flag from all images
            Image::where('imageable_type', get_class($imageable))
                ->where('imageable_id', $imageable->id)
                ->update(['is_primary' => false]);

            // Set new primary
            $image->update(['is_primary' => true]);
            $imageable->update(['primary_image_id' => $image->id]);
        });
    }

    public function attachUploadToEntity(Upload $upload, $entity): array
    {
        // Check if upload already attached to this entity (idempotent)
        $existingImages = Image::where('upload_id', $upload->id)
            ->where('imageable_type', get_class($entity))
            ->where('imageable_id', $entity->id)
            ->exists();

        if ($existingImages) {
            return Image::where('upload_id', $upload->id)
                ->where('imageable_type', get_class($entity))
                ->where('imageable_id', $entity->id)
                ->get()
                ->toArray();
        }

        // Link upload to entity
        $upload->update([
            'uploadable_type' => get_class($entity),
            'uploadable_id' => $entity->id,
        ]);

        return $this->generateVariants($upload, $entity);
    }
}
