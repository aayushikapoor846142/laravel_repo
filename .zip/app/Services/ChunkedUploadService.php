<?php

namespace App\Services;

use App\Models\Upload;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ChunkedUploadService
{
    private string $tempDisk = 'local';
    private string $chunkPath = 'chunks';

    public function initializeUpload(
        string $filename,
        string $mimeType,
        int $totalSize,
        int $totalChunks,
        string $checksum
    ): Upload {
        $upload = Upload::create([
            'filename' => Str::uuid() . '_' . $filename,
            'original_filename' => $filename,
            'mime_type' => $mimeType,
            'size' => $totalSize,
            'checksum' => $checksum,
            'total_chunks' => $totalChunks,
            'uploaded_chunks' => 0,
            'status' => 'pending',
        ]);

        $this->ensureChunkDirectory($upload->id);

        return $upload;
    }

    public function uploadChunk(Upload $upload, int $chunkIndex, string $chunkData): bool
    {
        if ($upload->status === 'completed') {
            return true;
        }

        $chunkPath = $this->getChunkPath($upload->id, $chunkIndex);

        // Check if chunk already exists (resume support)
        if (Storage::disk($this->tempDisk)->exists($chunkPath)) {
            return true;
        }

        $decoded = base64_decode($chunkData, true);
        if ($decoded === false) {
            throw new \InvalidArgumentException('Invalid base64 chunk data');
        }

        Storage::disk($this->tempDisk)->put($chunkPath, $decoded);

        $upload->increment('uploaded_chunks');
        $upload->update(['status' => 'uploading']);

        return true;
    }

    public function completeUpload(Upload $upload): bool
    {
        if ($upload->uploaded_chunks !== $upload->total_chunks) {
            throw new \RuntimeException('Not all chunks uploaded');
        }

        $finalPath = $this->assembleChunks($upload);
        
        // Validate checksum
        $actualChecksum = hash_file('sha256', Storage::disk($this->tempDisk)->path($finalPath));
        if ($actualChecksum !== $upload->checksum) {
            $this->cleanup($upload);
            throw new \RuntimeException('Checksum mismatch');
        }

        // Move to permanent storage
        $permanentPath = 'uploads/' . $upload->filename;
        Storage::disk('public')->put(
            $permanentPath,
            Storage::disk($this->tempDisk)->get($finalPath)
        );

        $upload->update([
            'status' => 'completed',
            'filename' => $permanentPath,
        ]);

        $this->cleanup($upload);

        return true;
    }

    private function assembleChunks(Upload $upload): string
    {
        $finalPath = "assembled/{$upload->id}_{$upload->original_filename}";
        $finalFullPath = Storage::disk($this->tempDisk)->path($finalPath);

        $handle = fopen($finalFullPath, 'wb');
        if ($handle === false) {
            throw new \RuntimeException('Unable to create final file');
        }

        for ($i = 0; $i < $upload->total_chunks; $i++) {
            $chunkPath = $this->getChunkPath($upload->id, $i);
            $chunkContent = Storage::disk($this->tempDisk)->get($chunkPath);
            fwrite($handle, $chunkContent);
        }

        fclose($handle);

        return $finalPath;
    }

    private function cleanup(Upload $upload): void
    {
        $chunkDir = "{$this->chunkPath}/{$upload->id}";
        Storage::disk($this->tempDisk)->deleteDirectory($chunkDir);

        $assembledFile = "assembled/{$upload->id}_{$upload->original_filename}";
        Storage::disk($this->tempDisk)->delete($assembledFile);
    }

    private function ensureChunkDirectory(int $uploadId): void
    {
        $dir = "{$this->chunkPath}/{$uploadId}";
        if (!Storage::disk($this->tempDisk)->exists($dir)) {
            Storage::disk($this->tempDisk)->makeDirectory($dir);
        }
    }

    private function getChunkPath(int $uploadId, int $chunkIndex): string
    {
        return "{$this->chunkPath}/{$uploadId}/chunk_{$chunkIndex}";
    }

    public function getUploadStatus(Upload $upload): array
    {
        return [
            'id' => $upload->id,
            'status' => $upload->status,
            'uploaded_chunks' => $upload->uploaded_chunks,
            'total_chunks' => $upload->total_chunks,
            'progress' => $upload->total_chunks > 0 
                ? round(($upload->uploaded_chunks / $upload->total_chunks) * 100, 2)
                : 0,
        ];
    }
}
