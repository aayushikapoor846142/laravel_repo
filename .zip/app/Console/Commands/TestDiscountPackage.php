<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use YourVendor\UserDiscounts\DiscountService;
use YourVendor\UserDiscounts\Models\Discount;
use App\Models\User;

class TestDiscountPackage extends Command
{
    protected $signature = 'test:discount-package';
    protected $description = 'Test the User Discounts package functionality';

    public function handle()
    {
        $this->info('Testing User Discounts Package...');
        $this->newLine();

        try {
            // Check if service is registered
            $this->info('1. Checking if DiscountService is registered...');
            $service = app(DiscountService::class);
            $this->info('   ✓ DiscountService is registered');
            $this->newLine();

            // Check if migrations ran
            $this->info('2. Checking database tables...');
            if (\Schema::hasTable('discounts')) {
                $this->info('   ✓ discounts table exists');
            } else {
                $this->error('   ✗ discounts table missing - run: php artisan migrate');
                return 1;
            }

            if (\Schema::hasTable('user_discounts')) {
                $this->info('   ✓ user_discounts table exists');
            } else {
                $this->error('   ✗ user_discounts table missing');
                return 1;
            }

            if (\Schema::hasTable('discount_audits')) {
                $this->info('   ✓ discount_audits table exists');
            } else {
                $this->error('   ✗ discount_audits table missing');
                return 1;
            }
            $this->newLine();

            // Create test discount
            $this->info('3. Creating test discount...');
            $discount = Discount::create([
                'code' => 'TEST20',
                'name' => 'Test 20% Off',
                'type' => 'percentage',
                'value' => 20,
                'is_active' => true,
            ]);
            $this->info("   ✓ Discount created: {$discount->code} - {$discount->name}");
            $this->newLine();

            // Create or get test user
            $this->info('4. Getting test user...');
            $user = User::first();
            if (!$user) {
                $this->warn('   ! No users found. Creating test user...');
                $user = User::create([
                    'name' => 'Test User',
                    'email' => 'test@example.com',
                    'password' => bcrypt('password'),
                ]);
            }
            $this->info("   ✓ User: {$user->name} ({$user->email})");
            $this->newLine();

            // Test assign function
            $this->info('5. Testing assign() function...');
            $userDiscount = $service->assign($user, $discount);
            $this->info("   ✓ Discount assigned to user (ID: {$userDiscount->id})");
            $this->newLine();

            // Test eligibleFor function
            $this->info('6. Testing eligibleFor() function...');
            $eligible = $service->eligibleFor($user);
            $this->info("   ✓ Found " . count($eligible) . " eligible discount(s)");
            foreach ($eligible as $disc) {
                $this->info("      - {$disc->code}: {$disc->name}");
            }
            $this->newLine();

            // Test apply function
            $this->info('7. Testing apply() function...');
            $amount = 100.00;
            $result = $service->apply($user, $amount);
            
            $this->table(
                ['Metric', 'Value'],
                [
                    ['Original Amount', '$' . number_format($result['original_amount'], 2)],
                    ['Discount Amount', '$' . number_format($result['discount_amount'], 2)],
                    ['Final Amount', '$' . number_format($result['final_amount'], 2)],
                    ['Discounts Applied', count($result['applied_discounts'])],
                ]
            );
            $this->newLine();

            // Test revoke function
            $this->info('8. Testing revoke() function...');
            $revoked = $service->revoke($user, $discount);
            if ($revoked) {
                $this->info('   ✓ Discount revoked successfully');
            } else {
                $this->warn('   ! Discount was already revoked');
            }
            $this->newLine();

            // Verify revocation
            $this->info('9. Verifying revocation...');
            $eligible = $service->eligibleFor($user);
            $this->info("   ✓ Eligible discounts after revocation: " . count($eligible));
            $this->newLine();

            // Cleanup
            $this->info('10. Cleaning up test data...');
            $discount->delete();
            if ($user->email === 'test@example.com') {
                $user->delete();
            }
            $this->info('   ✓ Test data cleaned up');
            $this->newLine();

            $this->info('✅ All package tests passed successfully!');
            $this->newLine();
            
            $this->info('Package is working correctly. You can now use it in your application:');
            $this->line('');
            $this->line('  $service = app(YourVendor\UserDiscounts\DiscountService::class);');
            $this->line('  $service->assign($user, $discount);');
            $this->line('  $result = $service->apply($user, 100.00);');
            
            return 0;

        } catch (\Exception $e) {
            $this->error('✗ Test failed: ' . $e->getMessage());
            $this->error('Stack trace:');
            $this->line($e->getTraceAsString());
            return 1;
        }
    }
}
