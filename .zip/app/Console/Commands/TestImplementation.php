<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\ProductImportService;
use App\Models\Product;

class TestImplementation extends Command
{
    protected $signature = 'test:implementation';
    protected $description = 'Test the implementation of Task A';

    public function handle()
    {
        $this->info('Testing Task A Implementation...');
        $this->newLine();

        // Generate test CSV
        $this->info('1. Generating test CSV with 100 products...');
        $csvPath = storage_path('app/test_products.csv');
        $this->generateTestCsv($csvPath, 100);
        $this->info("   ✓ CSV generated at: {$csvPath}");
        $this->newLine();

        // Test import
        $this->info('2. Testing CSV import...');
        $service = new ProductImportService();
        $results = $service->importFromCsv($csvPath);

        $this->table(
            ['Metric', 'Count'],
            [
                ['Total Rows', $results['total']],
                ['Imported', $results['imported']],
                ['Updated', $results['updated']],
                ['Invalid', $results['invalid']],
                ['Duplicates', $results['duplicates']],
            ]
        );
        $this->newLine();

        // Test upsert
        $this->info('3. Testing upsert behavior...');
        $this->info('   Re-importing same CSV to test updates...');
        $results2 = $service->importFromCsv($csvPath);
        
        $this->table(
            ['Metric', 'First Import', 'Second Import'],
            [
                ['Imported', $results['imported'], $results2['imported']],
                ['Updated', $results['updated'], $results2['updated']],
            ]
        );
        $this->newLine();

        // Verify database
        $this->info('4. Verifying database...');
        $productCount = Product::count();
        $this->info("   ✓ Products in database: {$productCount}");
        
        $sampleProduct = Product::first();
        if ($sampleProduct) {
            $this->info("   ✓ Sample product: {$sampleProduct->sku} - {$sampleProduct->name}");
        }
        $this->newLine();

        // Test with invalid data
        $this->info('5. Testing invalid data handling...');
        $invalidCsvPath = storage_path('app/test_invalid.csv');
        $this->generateInvalidCsv($invalidCsvPath);
        $results3 = $service->importFromCsv($invalidCsvPath);
        
        $this->table(
            ['Metric', 'Count'],
            [
                ['Total Rows', $results3['total']],
                ['Valid', $results3['imported'] + $results3['updated']],
                ['Invalid', $results3['invalid']],
                ['Duplicates', $results3['duplicates']],
            ]
        );
        $this->newLine();

        $this->info('✓ All tests completed successfully!');
        $this->newLine();
        
        // Cleanup
        unlink($csvPath);
        unlink($invalidCsvPath);
        
        return 0;
    }

    private function generateTestCsv(string $path, int $rows): void
    {
        $handle = fopen($path, 'w');
        fputcsv($handle, ['sku', 'name', 'description', 'price', 'stock']);

        for ($i = 1; $i <= $rows; $i++) {
            fputcsv($handle, [
                'TEST-SKU-' . str_pad($i, 5, '0', STR_PAD_LEFT),
                'Test Product ' . $i,
                'Description for test product ' . $i,
                rand(10, 500) + (rand(0, 99) / 100),
                rand(0, 100),
            ]);
        }

        fclose($handle);
    }

    private function generateInvalidCsv(string $path): void
    {
        $handle = fopen($path, 'w');
        fputcsv($handle, ['sku', 'name', 'description', 'price', 'stock']);

        // Valid row
        fputcsv($handle, ['VALID-001', 'Valid Product', 'Description', '99.99', '10']);
        
        // Missing SKU
        fputcsv($handle, ['', 'Missing SKU', 'Description', '50.00', '5']);
        
        // Missing name
        fputcsv($handle, ['INVALID-002', '', 'Description', '75.00', '8']);
        
        // Missing price
        fputcsv($handle, ['INVALID-003', 'Missing Price', 'Description', '', '12']);
        
        // Duplicate SKU in CSV
        fputcsv($handle, ['VALID-001', 'Duplicate', 'Description', '100.00', '20']);
        
        // Another valid row
        fputcsv($handle, ['VALID-002', 'Another Valid', 'Description', '149.99', '15']);

        fclose($handle);
    }
}
