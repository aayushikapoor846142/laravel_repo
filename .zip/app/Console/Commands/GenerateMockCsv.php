<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class GenerateMockCsv extends Command
{
    protected $signature = 'generate:mock-csv {rows=10000} {--path=storage/app/mock_products.csv}';
    protected $description = 'Generate mock CSV data for testing bulk import';

    public function handle()
    {
        $rows = (int) $this->argument('rows');
        $path = $this->option('path');

        $this->info("Generating {$rows} rows of mock product data...");

        $handle = fopen($path, 'w');
        
        // Write headers
        fputcsv($handle, ['sku', 'name', 'description', 'price', 'stock']);

        // Generate data
        for ($i = 1; $i <= $rows; $i++) {
            fputcsv($handle, [
                'SKU' . str_pad($i, 6, '0', STR_PAD_LEFT),
                'Product ' . $i,
                'Description for product ' . $i,
                rand(10, 1000) + (rand(0, 99) / 100),
                rand(0, 500),
            ]);

            if ($i % 1000 === 0) {
                $this->info("Generated {$i} rows...");
            }
        }

        fclose($handle);

        $this->info("Mock CSV generated successfully at: {$path}");
        $this->info("Total rows: {$rows}");
    }
}
