<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Upload extends Model
{
    protected $fillable = [
        'filename',
        'original_filename',
        'mime_type',
        'size',
        'checksum',
        'total_chunks',
        'uploaded_chunks',
        'status',
        'uploadable_type',
        'uploadable_id',
    ];

    protected $casts = [
        'size' => 'integer',
        'total_chunks' => 'integer',
        'uploaded_chunks' => 'integer',
    ];

    public function uploadable(): MorphTo
    {
        return $this->morphTo();
    }

    public function images(): HasMany
    {
        return $this->hasMany(Image::class);
    }

    public function isComplete(): bool
    {
        return $this->status === 'completed' && $this->uploaded_chunks === $this->total_chunks;
    }
}
