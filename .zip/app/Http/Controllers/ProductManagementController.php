<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductManagementController extends Controller
{
    public function index()
    {
        $products = Product::latest()->paginate(20);
        return view('products.index', compact('products'));
    }

    public function import()
    {
        return view('products.import');
    }

    public function upload()
    {
        return view('products.upload');
    }

    public function show(Product $product)
    {
        $product->load(['images', 'primaryImage']);
        return view('products.show', compact('product'));
    }
}
