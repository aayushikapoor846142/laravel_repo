<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Upload;
use App\Services\ChunkedUploadService;
use App\Services\ImageVariantService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ChunkedUploadController extends Controller
{
    public function __construct(
        private ChunkedUploadService $uploadService,
        private ImageVariantService $variantService
    ) {}

    public function initialize(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'filename' => 'required|string',
            'mime_type' => 'required|string',
            'total_size' => 'required|integer|min:1',
            'total_chunks' => 'required|integer|min:1',
            'checksum' => 'required|string|size:64',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            $upload = $this->uploadService->initializeUpload(
                $request->filename,
                $request->mime_type,
                $request->total_size,
                $request->total_chunks,
                $request->checksum
            );

            return response()->json([
                'upload_id' => $upload->id,
                'status' => $upload->status,
            ], 201);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function uploadChunk(Request $request, Upload $upload)
    {
        $validator = Validator::make($request->all(), [
            'chunk_index' => 'required|integer|min:0',
            'chunk_data' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            $this->uploadService->uploadChunk(
                $upload,
                $request->chunk_index,
                $request->chunk_data
            );

            $status = $this->uploadService->getUploadStatus($upload->fresh());

            return response()->json($status);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function complete(Request $request, Upload $upload)
    {
        try {
            $this->uploadService->completeUpload($upload);

            return response()->json([
                'message' => 'Upload completed successfully',
                'upload_id' => $upload->id,
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function status(Upload $upload)
    {
        return response()->json($this->uploadService->getUploadStatus($upload));
    }

    public function attachToProduct(Request $request, Upload $upload)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
            'set_as_primary' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            $product = \App\Models\Product::findOrFail($request->product_id);
            
            $images = $this->variantService->attachUploadToEntity($upload, $product);

            if ($request->boolean('set_as_primary') && count($images) > 0) {
                $this->variantService->setPrimaryImage($product, $images[0]);
            }

            return response()->json([
                'message' => 'Images attached successfully',
                'images' => $images,
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
