<?php

namespace Tests\Unit;

use Tests\TestCase;
use App\Services\ProductImportService;
use App\Models\Product;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ProductImportServiceTest extends TestCase
{
    use RefreshDatabase;

    private ProductImportService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new ProductImportService();
    }

    public function test_upsert_creates_new_product(): void
    {
        $csvContent = "sku,name,description,price,stock\n";
        $csvContent .= "TEST001,Test Product,Test Description,99.99,10\n";
        
        $tempFile = tempnam(sys_get_temp_dir(), 'csv');
        file_put_contents($tempFile, $csvContent);

        $results = $this->service->importFromCsv($tempFile);

        $this->assertEquals(1, $results['total']);
        $this->assertEquals(1, $results['imported']);
        $this->assertEquals(0, $results['updated']);
        $this->assertEquals(0, $results['invalid']);
        $this->assertEquals(0, $results['duplicates']);

        $product = Product::where('sku', 'TEST001')->first();
        $this->assertNotNull($product);
        $this->assertEquals('Test Product', $product->name);
        $this->assertEquals(99.99, $product->price);

        unlink($tempFile);
    }

    public function test_upsert_updates_existing_product(): void
    {
        Product::create([
            'sku' => 'TEST001',
            'name' => 'Old Name',
            'price' => 50.00,
            'stock' => 5,
        ]);

        $csvContent = "sku,name,description,price,stock\n";
        $csvContent .= "TEST001,Updated Name,Updated Description,99.99,20\n";
        
        $tempFile = tempnam(sys_get_temp_dir(), 'csv');
        file_put_contents($tempFile, $csvContent);

        $results = $this->service->importFromCsv($tempFile);

        $this->assertEquals(1, $results['total']);
        $this->assertEquals(0, $results['imported']);
        $this->assertEquals(1, $results['updated']);

        $product = Product::where('sku', 'TEST001')->first();
        $this->assertEquals('Updated Name', $product->name);
        $this->assertEquals(99.99, $product->price);
        $this->assertEquals(20, $product->stock);

        unlink($tempFile);
    }

    public function test_invalid_rows_are_counted(): void
    {
        $csvContent = "sku,name,description,price,stock\n";
        $csvContent .= "TEST001,Test Product,Description,99.99,10\n";
        $csvContent .= ",Missing SKU,Description,50.00,5\n";
        $csvContent .= "TEST003,Missing Price,,\n";
        
        $tempFile = tempnam(sys_get_temp_dir(), 'csv');
        file_put_contents($tempFile, $csvContent);

        $results = $this->service->importFromCsv($tempFile);

        $this->assertEquals(3, $results['total']);
        $this->assertEquals(1, $results['imported']);
        $this->assertEquals(2, $results['invalid']);

        unlink($tempFile);
    }

    public function test_duplicate_skus_in_csv_are_counted(): void
    {
        $csvContent = "sku,name,description,price,stock\n";
        $csvContent .= "TEST001,First Product,Description,99.99,10\n";
        $csvContent .= "TEST001,Duplicate Product,Description,50.00,5\n";
        
        $tempFile = tempnam(sys_get_temp_dir(), 'csv');
        file_put_contents($tempFile, $csvContent);

        $results = $this->service->importFromCsv($tempFile);

        $this->assertEquals(2, $results['total']);
        $this->assertEquals(1, $results['imported']);
        $this->assertEquals(1, $results['duplicates']);

        $this->assertEquals(1, Product::count());

        unlink($tempFile);
    }

    public function test_large_csv_import(): void
    {
        $csvContent = "sku,name,description,price,stock\n";
        
        for ($i = 1; $i <= 100; $i++) {
            $csvContent .= "SKU{$i},Product {$i},Description {$i}," . ($i * 10) . ",{$i}\n";
        }
        
        $tempFile = tempnam(sys_get_temp_dir(), 'csv');
        file_put_contents($tempFile, $csvContent);

        $results = $this->service->importFromCsv($tempFile);

        $this->assertEquals(100, $results['total']);
        $this->assertEquals(100, $results['imported']);
        $this->assertEquals(100, Product::count());

        unlink($tempFile);
    }
}
