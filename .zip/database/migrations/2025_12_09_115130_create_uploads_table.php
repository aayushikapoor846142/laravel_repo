<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('uploads', function (Blueprint $table) {
            $table->id();
            $table->string('filename');
            $table->string('original_filename');
            $table->string('mime_type');
            $table->bigInteger('size');
            $table->string('checksum', 64);
            $table->bigInteger('total_chunks');
            $table->bigInteger('uploaded_chunks')->default(0);
            $table->enum('status', ['pending', 'uploading', 'completed', 'failed'])->default('pending');
            $table->morphs('uploadable');
            $table->timestamps();
            
            $table->index('checksum');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('uploads');
    }
};
