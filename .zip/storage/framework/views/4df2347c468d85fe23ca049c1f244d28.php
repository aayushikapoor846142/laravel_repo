<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business FHC - Assessment Complete</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }

        .success-header {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }

        .success-icon {
            font-size: 60px;
            margin-bottom: 20px;
        }

        .success-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .content {
            padding: 40px 30px;
        }

        .section {
            margin-bottom: 35px;
        }

        .section-title {
            font-size: 20px;
            color: #667eea;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
            font-weight: 600;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }

        .info-label {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .info-value {
            font-size: 16px;
            color: #333;
            font-weight: 600;
        }

        .score-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .score-card {
            background: #f9fafb;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border-left: 4px solid #667eea;
        }

        .score-card h3 {
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        .score-card .value {
            font-size: 28px;
            font-weight: 700;
            color: #1f2937;
        }

        .score-card .value.low {
            color: #10b981;
        }

        .score-card .value.medium {
            color: #f59e0b;
        }

        .score-card .value.high {
            color: #ef4444;
        }

        .table-container {
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        table th {
            background: #f3f4f6;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid #e5e7eb;
        }

        table td {
            padding: 12px;
            border-bottom: 1px solid #e5e7eb;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-adequate {
            background: #d1fae5;
            color: #065f46;
        }

        .status-partial {
            background: #fef3c7;
            color: #92400e;
        }

        .status-major {
            background: #fee2e2;
            color: #991b1b;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 40px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }

        @media print {
            .action-buttons {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-header">
            <div class="success-icon">✓</div>
            <h1>Assessment Completed Successfully!</h1>
            <p>Business Financial Health Check Report</p>
        </div>

        <div class="content">
            <!-- Advisor Information -->
            <div class="section">
                <h2 class="section-title">Advisor Information</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Advisor / Firm Name</div>
                        <div class="info-value"><?php echo e($businessFhc->advisor_name); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Contact</div>
                        <div class="info-value"><?php echo e($businessFhc->advisor_contact); ?></div>
                    </div>
                </div>
            </div>

            <!-- Business Information -->
            <div class="section">
                <h2 class="section-title">Business Information</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Business Name</div>
                        <div class="info-value"><?php echo e($businessFhc->business_name); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Owner / Contact Person</div>
                        <div class="info-value"><?php echo e($businessFhc->owner_name); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Business Type</div>
                        <div class="info-value"><?php echo e($businessFhc->business_type); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Partners / Directors</div>
                        <div class="info-value"><?php echo e($businessFhc->num_partners); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Annual Turnover</div>
                        <div class="info-value">₹<?php echo e(number_format($businessFhc->turnover, 2)); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Net Profit</div>
                        <div class="info-value">₹<?php echo e(number_format($businessFhc->net_profit, 2)); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Number of Employees</div>
                        <div class="info-value"><?php echo e($businessFhc->num_employees); ?></div>
                    </div>
                </div>
            </div>

            <!-- Existing Insurance Covers -->
            <div class="section">
                <h2 class="section-title">Existing Insurance Covers</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Keyman Insurance</div>
                        <div class="info-value">₹<?php echo e(number_format($businessFhc->existing_keyman, 2)); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Partnership / Shareholder Protection</div>
                        <div class="info-value">₹<?php echo e(number_format($businessFhc->existing_partnership, 2)); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Group Health</div>
                        <div class="info-value">₹<?php echo e(number_format($businessFhc->existing_group_health, 2)); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Fire / Asset Insurance</div>
                        <div class="info-value">₹<?php echo e(number_format($businessFhc->existing_fire, 2)); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Liability Insurance</div>
                        <div class="info-value">₹<?php echo e(number_format($businessFhc->existing_liability, 2)); ?></div>
                    </div>
                </div>
            </div>

            <!-- Results & Recommendations -->
            <div class="section">
                <h2 class="section-title">Results & Recommendations</h2>
                
                <div class="score-cards">
                    <div class="score-card">
                        <h3>Overall Score</h3>
                        <div class="value <?php echo e(strtolower($businessFhc->overall_score)); ?>"><?php echo e($businessFhc->overall_score); ?></div>
                    </div>
                    <div class="score-card">
                        <h3>Risk Score</h3>
                        <div class="value"><?php echo e($businessFhc->risk_score); ?>/15</div>
                    </div>
                    <div class="score-card">
                        <h3>Major Gaps</h3>
                        <div class="value"><?php echo e($businessFhc->major_gaps); ?></div>
                    </div>
                    <div class="score-card">
                        <h3>Partial Gaps</h3>
                        <div class="value"><?php echo e($businessFhc->partial_gaps); ?></div>
                    </div>
                    <div class="score-card">
                        <h3>Adequate Areas</h3>
                        <div class="value"><?php echo e($businessFhc->adequate_areas); ?></div>
                    </div>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Recommended (₹)</th>
                                <th>Existing (₹)</th>
                                <th>Gap (₹)</th>
                                <th>Adequacy %</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $businessFhc->results_data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($category['name']); ?></strong></td>
                                <td>₹<?php echo e(number_format($category['recommended'], 2)); ?></td>
                                <td>₹<?php echo e(number_format($category['existing'], 2)); ?></td>
                                <td>₹<?php echo e(number_format($category['gap'], 2)); ?></td>
                                <td><?php echo e(number_format($category['adequacy'], 0)); ?>%</td>
                                <td>
                                    <?php if($category['adequacy'] >= 80): ?>
                                        <span class="status-badge status-adequate">Adequate</span>
                                    <?php elseif($category['adequacy'] >= 50): ?>
                                        <span class="status-badge status-partial">Partial Gap</span>
                                    <?php else: ?>
                                        <span class="status-badge status-major">Major Gap</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if($businessFhc->footer_note): ?>
            <div class="section">
                <h2 class="section-title">Additional Notes</h2>
                <div class="info-item">
                    <div class="info-value"><?php echo e($businessFhc->footer_note); ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <button onclick="window.print()" class="btn btn-secondary">Print / Save PDF</button>
                <a href="<?php echo e(route('business-fhc.index')); ?>" class="btn btn-secondary">New Assessment</a>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\crm-task\resources\views/business-fhc-success.blade.php ENDPATH**/ ?>