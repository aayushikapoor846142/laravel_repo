

<?php $__env->startSection('title', 'Import Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 py-6 sm:px-0">
    <div class="bg-white shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">
                Import Products from CSV
            </h3>
            
            <div x-data="csvImporter()" class="space-y-4">
                <!-- File Upload Area -->
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition"
                     @dragover.prevent="dragover = true"
                     @dragleave.prevent="dragover = false"
                     @drop.prevent="handleDrop($event)"
                     :class="{ 'border-blue-500 bg-blue-50': dragover }">
                    
                    <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    
                    <div class="mt-4">
                        <label for="csv-file" class="cursor-pointer">
                            <span class="mt-2 block text-sm font-medium text-gray-900">
                                Drop CSV file here or click to browse
                            </span>
                            <input id="csv-file" 
                                   type="file" 
                                   accept=".csv,.txt"
                                   class="hidden" 
                                   @change="handleFileSelect($event)">
                        </label>
                        <p class="mt-1 text-xs text-gray-500">CSV or TXT files only</p>
                    </div>
                </div>

                <!-- Selected File Info -->
                <div x-show="file" class="bg-gray-50 rounded-lg p-4">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <svg class="h-8 w-8 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clip-rule="evenodd" />
                            </svg>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-gray-900" x-text="file?.name"></p>
                                <p class="text-xs text-gray-500" x-text="formatFileSize(file?.size)"></p>
                            </div>
                        </div>
                        <button @click="clearFile()" class="text-red-600 hover:text-red-800">
                            <svg class="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Import Button -->
                <div>
                    <button @click="importCSV()" 
                            :disabled="!file || importing"
                            class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed">
                        <span x-show="!importing">Import Products</span>
                        <span x-show="importing" class="flex items-center">
                            <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Importing...
                        </span>
                    </button>
                </div>

                <!-- Progress Bar -->
                <div x-show="importing" class="space-y-2">
                    <div class="w-full bg-gray-200 rounded-full h-2.5">
                        <div class="bg-blue-600 h-2.5 rounded-full transition-all duration-300" 
                             :style="`width: ${progress}%`"></div>
                    </div>
                    <p class="text-sm text-gray-600 text-center" x-text="`Processing... ${progress}%`"></p>
                </div>

                <!-- Results -->
                <div x-show="results" class="bg-white border border-gray-200 rounded-lg p-4">
                    <h4 class="text-lg font-medium text-gray-900 mb-4">Import Results</h4>
                    <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div class="text-center">
                            <p class="text-2xl font-bold text-gray-900" x-text="results?.total || 0"></p>
                            <p class="text-xs text-gray-500">Total Rows</p>
                        </div>
                        <div class="text-center">
                            <p class="text-2xl font-bold text-green-600" x-text="results?.imported || 0"></p>
                            <p class="text-xs text-gray-500">Imported</p>
                        </div>
                        <div class="text-center">
                            <p class="text-2xl font-bold text-blue-600" x-text="results?.updated || 0"></p>
                            <p class="text-xs text-gray-500">Updated</p>
                        </div>
                        <div class="text-center">
                            <p class="text-2xl font-bold text-red-600" x-text="results?.invalid || 0"></p>
                            <p class="text-xs text-gray-500">Invalid</p>
                        </div>
                        <div class="text-center">
                            <p class="text-2xl font-bold text-yellow-600" x-text="results?.duplicates || 0"></p>
                            <p class="text-xs text-gray-500">Duplicates</p>
                        </div>
                    </div>
                </div>

                <!-- Error Message -->
                <div x-show="error" class="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p class="text-sm text-red-800" x-text="error"></p>
                </div>
            </div>
        </div>
    </div>

    <!-- CSV Format Guide -->
    <div class="mt-6 bg-white shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">
                CSV Format Guide
            </h3>
            <div class="prose prose-sm max-w-none">
                <p class="text-gray-600">Your CSV file should have the following columns:</p>
                <ul class="list-disc list-inside text-gray-600 space-y-1">
                    <li><strong>sku</strong> (required) - Unique product identifier</li>
                    <li><strong>name</strong> (required) - Product name</li>
                    <li><strong>price</strong> (required) - Product price</li>
                    <li><strong>description</strong> (optional) - Product description</li>
                    <li><strong>stock</strong> (optional) - Stock quantity</li>
                </ul>
                <div class="mt-4 bg-gray-50 rounded p-3">
                    <p class="text-xs font-mono text-gray-700">
                        sku,name,description,price,stock<br>
                        SKU001,Product 1,Description here,99.99,100<br>
                        SKU002,Product 2,Another description,149.50,50
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function csvImporter() {
    return {
        file: null,
        dragover: false,
        importing: false,
        progress: 0,
        results: null,
        error: null,

        handleDrop(e) {
            this.dragover = false;
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.file = files[0];
            }
        },

        handleFileSelect(e) {
            const files = e.target.files;
            if (files.length > 0) {
                this.file = files[0];
            }
        },

        clearFile() {
            this.file = null;
            this.results = null;
            this.error = null;
            document.getElementById('csv-file').value = '';
        },

        formatFileSize(bytes) {
            if (!bytes) return '';
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(1024));
            return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
        },

        async importCSV() {
            if (!this.file) return;

            this.importing = true;
            this.progress = 0;
            this.results = null;
            this.error = null;

            const formData = new FormData();
            formData.append('csv_file', this.file);

            // Simulate progress
            const progressInterval = setInterval(() => {
                if (this.progress < 90) {
                    this.progress += 10;
                }
            }, 200);

            try {
                const response = await fetch('<?php echo e(route("api.products.import")); ?>', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: formData
                });

                clearInterval(progressInterval);
                this.progress = 100;

                const data = await response.json();

                if (response.ok) {
                    this.results = data.results;
                    setTimeout(() => {
                        this.clearFile();
                        this.importing = false;
                    }, 2000);
                } else {
                    this.error = data.error || 'Import failed';
                    this.importing = false;
                }
            } catch (err) {
                clearInterval(progressInterval);
                this.error = 'Network error: ' + err.message;
                this.importing = false;
            }
        }
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\t_task\resources\views/products/import.blade.php ENDPATH**/ ?>