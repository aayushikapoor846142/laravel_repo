<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Financial Plans</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 28px;
            font-weight: 600;
        }

        .btn {
            padding: 12px 24px;
            background: white;
            color: #667eea;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .content {
            padding: 30px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #667eea;
            border-bottom: 2px solid #667eea;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }

        tr:hover {
            background: #f8f9fa;
        }

        .action-link {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }

        .empty-state h2 {
            font-size: 24px;
            margin-bottom: 15px;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-chart-line"></i> Financial Plans</h1>
            <a href="<?php echo e(route('financial-plan.create')); ?>" class="btn">+ New Financial Plan</a>
        </div>

        <div class="content">
            <?php if($plans->count() > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Client Name</th>
                            <th>Age</th>
                            <th>Contact</th>
                            <th>Net Worth</th>
                            <th>Risk Profile</th>
                            <th>Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($plan->id); ?></td>
                            <td><?php echo e($plan->full_name); ?></td>
                            <td><?php echo e($plan->age ?? 'N/A'); ?></td>
                            <td><?php echo e($plan->contact ?? 'N/A'); ?></td>
                            <td>₹<?php echo e(number_format(($plan->equity + $plan->debt + $plan->real_estate + $plan->gold + $plan->cash) - ($plan->home_loan + $plan->car_loan + $plan->other_loans), 0)); ?></td>
                            <td><?php echo e($plan->risk_profile ?? 'Not Set'); ?></td>
                            <td><?php echo e($plan->created_at->format('d M, Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('financial-plan.show', $plan->id)); ?>" class="action-link">View Details</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top: 30px;">
                <?php echo e($plans->links()); ?>

            </div>
            <?php else: ?>
            <div class="empty-state">
                <h2>No Financial Plans Found</h2>
                <p>Start by creating your first comprehensive financial plan</p>
                <a href="<?php echo e(route('financial-plan.create')); ?>" class="btn" style="margin-top: 20px;">Create First Plan</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\crm-task\resources\views/financial-plan-index.blade.php ENDPATH**/ ?>