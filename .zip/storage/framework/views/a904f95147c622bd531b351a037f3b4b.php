
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARS Kundli - Advance</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 30px 20px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 40px;
            text-align: center;
        }

        .nav-item {
            padding: 15px 20px;
            margin-bottom: 10px;
            cursor: pointer;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.1);
        }

        .nav-item.active {
            background: rgba(255,255,255,0.2);
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        .nav-item i {
            font-size: 20px;
        }

        .main-content {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 28px;
            color: #1e3c72;
        }

        .print-btn {
            padding: 12px 24px;
            background: #1e3c72;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            transition: all 0.3s;
        }

        .print-btn:hover {
            background: #2a5298;
            transform: translateY(-2px);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #1e3c72;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .subtitle {
            font-size: 16px;
            font-weight: 600;
            margin: 20px 0 15px;
            color: #2a5298;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 14px;
            margin-bottom: 6px;
            color: #555;
            font-weight: 500;
        }

        .form-group input, .form-group select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border 0.3s;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #2a5298;
        }

        .divider {
            height: 1px;
            background: #e0e0e0;
            margin: 25px 0;
        }

        .add-btn {
            padding: 10px 20px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 15px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .add-btn:hover {
            background: #45a049;
        }

        .child-item {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 6px;
            margin-top: 10px;
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .remove-btn {
            padding: 6px 12px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }

        .risk-question {
            margin-bottom: 30px;
        }

        .risk-question h3 {
            font-size: 16px;
            margin-bottom: 15px;
            color: #333;
        }

        .risk-options {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .risk-option {
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            background: white;
        }

        .risk-option:hover {
            border-color: #2a5298;
            background: #f0f4ff;
        }

        .risk-option.selected {
            border-color: #2a5298;
            background: #e3eaff;
            font-weight: 500;
        }

        .risk-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .risk-profile-result {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .profile-status {
            text-align: center;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .profile-status.conservative {
            background: #fff3cd;
            color: #856404;
        }

        .profile-status.moderate {
            background: #d1ecf1;
            color: #0c5460;
        }

        .profile-status.aggressive {
            background: #f8d7da;
            color: #721c24;
        }

        .goal-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
        }

        .goal-tab-btn {
            padding: 12px 24px;
            background: #e0e0e0;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
        }

        .goal-tab-btn.active {
            background: #1e3c72;
            color: white;
        }

        .goal-section {
            display: none;
        }

        .goal-section.active {
            display: block;
        }

        .calculate-btn {
            padding: 12px 30px;
            background: #1e3c72;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
            transition: all 0.3s;
        }

        .calculate-btn:hover {
            background: #2a5298;
        }

        .goal-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            margin-top: 25px;
        }

        .goal-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .goal-table th, .goal-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        .goal-table th {
            background: #f5f7fa;
            font-weight: 600;
            color: #1e3c72;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            text-align: center;
        }

        .summary-card h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }

        .summary-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #1e3c72;
        }

        .action-items {
            background: #e8f5e9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .action-items h3 {
            color: #2e7d32;
            margin-bottom: 15px;
        }

        .action-items ul {
            list-style: none;
            padding: 0;
        }

        .action-items li {
            padding: 8px 0;
            color: #1b5e20;
        }

        .action-items li:before {
            content: "✓ ";
            color: #4CAF50;
            font-weight: bold;
            margin-right: 8px;
        }

        .ai-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px;
            border-radius: 10px;
            color: white;
            margin-top: 30px;
        }

        .ai-section h3 {
            margin-bottom: 15px;
        }

        .generate-ai-btn {
            padding: 12px 30px;
            background: white;
            color: #667eea;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .generate-ai-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        .ai-output {
            background: rgba(255,255,255,0.1);
            padding: 20px;
            border-radius: 8px;
            margin-top: 15px;
            line-height: 1.6;
            display: none;
        }

        .disclaimer {
            background: #fff3cd;
            padding: 20px;
            border-radius: 8px;
            margin-top: 30px;
            border-left: 4px solid #ffc107;
        }

        .disclaimer h4 {
            color: #856404;
            margin-bottom: 10px;
        }

        .disclaimer p {
            color: #856404;
            font-size: 13px;
            line-height: 1.6;
        }

        .chart-container {
            width: 100%;
            height: 300px;
            margin-top: 20px;
        }

        .dynamic-text {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 6px;
            margin: 15px 0;
            color: #1565c0;
            font-size: 14px;
        }

        .years-input-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .years-input-group input {
            flex: 1;
        }

        .years-input-group span {
            color: #666;
            font-weight: 500;
        }

        @media print {
            .sidebar, .print-btn, .nav-item {
                display: none;
            }
            .main-content {
                padding: 0;
            }
        }

        @media (max-width: 768px) {
            .risk-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo">ARS Kundli - Advance</div>
            <div class="nav-item active" onclick="switchTab(0)">
                <i class="fas fa-database"></i>
                <span>Data Inputs</span>
            </div>
            <div class="nav-item" onclick="switchTab(1)">
                <i class="fas fa-chart-line"></i>
                <span>Risk Profiler</span>
            </div>
            <div class="nav-item" onclick="switchTab(2)">
                <i class="fas fa-bullseye"></i>
                <span>Goal Planning</span>
            </div>
            <div class="nav-item" onclick="switchTab(3)">
                <i class="fas fa-file-alt"></i>
                <span>Summary Report</span>
            </div>
        </div>

        <div class="main-content">
            <div class="header">
                <h1 id="pageTitle">Data Collection</h1>
                <button class="print-btn" onclick="window.print()">
                    <i class="fas fa-download"></i>
                    Print / Save PDF
                </button>
            </div>

            <!-- Tab 1: Data Inputs -->
            <div class="tab-content active" id="tab0">
                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-user"></i>
                        Client Details
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" id="fullName" name="full_name" placeholder="Enter full name" required>
                        </div>
                        <div class="form-group">
                            <label>Age</label>
                            <input type="number" id="age" name="age" placeholder="Enter age">
                        </div>
                        <div class="form-group">
                            <label>Date of Birth</label>
                            <input type="date" id="dob" name="dob">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" id="email" name="email" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                            <label>Contact</label>
                            <input type="tel" id="contact" name="contact" placeholder="Enter contact number">
                        </div>
                        <div class="form-group">
                            <label>Dependents</label>
                            <input type="number" id="dependents" name="dependents" placeholder="Number of dependents">
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-users"></i>
                        Family Details
                    </div>
                    <div class="subtitle">Spouse</div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" id="spouseName" name="spouse_name" placeholder="Spouse name">
                        </div>
                        <div class="form-group">
                            <label>Age</label>
                            <input type="number" id="spouseAge" name="spouse_age" value="30">
                        </div>
                    </div>
                    
                    <div class="subtitle" style="margin-top: 20px;">Children</div>
                    <div id="childrenContainer"></div>
                    <button class="add-btn" onclick="addChild()">
                        <i class="fas fa-plus"></i>
                        Add Child
                    </button>
                </div>

                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-wallet"></i>
                        Financial Snapshot
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Monthly Income</label>
                            <input type="number" id="monthlyIncome" name="monthly_income" placeholder="Enter monthly income">
                        </div>
                        <div class="form-group">
                            <label>Monthly Expense</label>
                            <input type="number" id="monthlyExpense" name="monthly_expense" placeholder="Enter monthly expense">
                        </div>
                        <div class="form-group">
                            <label>Existing Life Insurance Cover</label>
                            <input type="number" id="lifeInsurance" name="life_insurance" placeholder="Enter life insurance">
                        </div>
                        <div class="form-group">
                            <label>Existing Health Insurance Cover</label>
                            <input type="number" id="healthInsurance" name="health_insurance" placeholder="Enter health insurance">
                        </div>
                    </div>

                    <div class="divider"></div>
                    <div class="subtitle">Current Assets</div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Equity</label>
                            <input type="number" id="equity" name="equity" placeholder="Enter equity" value="0">
                        </div>
                        <div class="form-group">
                            <label>Debt</label>
                            <input type="number" id="debt" name="debt" placeholder="Enter debt" value="0">
                        </div>
                        <div class="form-group">
                            <label>Real Estate</label>
                            <input type="number" id="realEstate" name="real_estate" placeholder="Enter real estate" value="0">
                        </div>
                        <div class="form-group">
                            <label>Gold</label>
                            <input type="number" id="gold" name="gold" placeholder="Enter gold" value="0">
                        </div>
                        <div class="form-group">
                            <label>Cash</label>
                            <input type="number" id="cash" name="cash" placeholder="Enter cash" value="0">
                        </div>
                    </div>

                    <div class="divider"></div>
                    <div class="subtitle">Liabilities</div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Home Loan</label>
                            <input type="number" id="homeLoan" name="home_loan" placeholder="Enter home loan" value="0">
                        </div>
                        <div class="form-group">
                            <label>Car Loan</label>
                            <input type="number" id="carLoan" name="car_loan" placeholder="Enter car loan" value="0">
                        </div>
                        <div class="form-group">
                            <label>Other Loans</label>
                            <input type="number" id="otherLoans" name="other_loans" placeholder="Enter other loans" value="0">
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-cog"></i>
                        Planning Assumptions
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>General Inflation (%)</label>
                            <input type="number" id="generalInflation" name="general_inflation" value="6">
                        </div>
                        <div class="form-group">
                            <label>Education Inflation (%)</label>
                            <input type="number" id="educationInflation" name="education_inflation" value="10">
                        </div>
                        <div class="form-group">
                            <label>Inv. Return (Growth) (%)</label>
                            <input type="number" id="invReturn" name="inv_return" value="12">
                        </div>
                        <div class="form-group">
                            <label>Post-Retirement Return (%)</label>
                            <input type="number" id="postRetirementReturn" name="post_retirement_return" value="7">
                        </div>
                        <div class="form-group">
                            <label>Life Expectancy (Yrs)</label>
                            <input type="number" id="lifeExpectancy" name="life_expectancy" value="85">
                        </div>
                    </div>
                </div>

                <!-- Navigation Buttons -->
                <div style="display: flex; justify-content: flex-end; margin-top: 30px; gap: 15px;">
                    <button class="calculate-btn" onclick="switchTab(1)" style="background: #1e3c72;">
                        Next: Risk Profiler <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>

            <!-- Tab 2: Risk Profiler -->
            <div class="tab-content" id="tab1">
                <div class="risk-container">
                    <div>
                        <div class="section">
                            <div class="risk-question">
                                <h3>1. What is your primary goal for your investments?</h3>
                                <div class="risk-options">
                                    <div class="risk-option" onclick="selectRiskOption(0, 0, this)">
                                        Preserve Capital (Avoid loss)
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(0, 1, this)">
                                        Balanced Growth with moderate risk
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(0, 2, this)">
                                        Maximum Returns (Willing to take high risk)
                                    </div>
                                </div>
                            </div>

                            <div class="risk-question">
                                <h3>2. If your portfolio drops by 20% in a month, what would you do?</h3>
                                <div class="risk-options">
                                    <div class="risk-option" onclick="selectRiskOption(1, 0, this)">
                                        Sell everything immediately
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(1, 1, this)">
                                        Hold and wait for recovery
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(1, 2, this)">
                                        Invest more (Buy the dip)
                                    </div>
                                </div>
                            </div>

                            <div class="risk-question">
                                <h3>3. How long do you plan to stay invested?</h3>
                                <div class="risk-options">
                                    <div class="risk-option" onclick="selectRiskOption(2, 0, this)">
                                        Less than 3 years
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(2, 1, this)">
                                        3 to 7 years
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(2, 2, this)">
                                        More than 7 years
                                    </div>
                                </div>
                            </div>

                            <div class="risk-question">
                                <h3>4. What is your experience with equity markets?</h3>
                                <div class="risk-options">
                                    <div class="risk-option" onclick="selectRiskOption(3, 0, this)">
                                        No experience
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(3, 1, this)">
                                        Some experience with Mutual Funds
                                    </div>
                                    <div class="risk-option" onclick="selectRiskOption(3, 2, this)">
                                        Active stock trader
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="risk-profile-result">
                        <h3 style="margin-bottom: 20px;">Risk Profile Analysis</h3>
                        <div id="profileStatus" class="profile-status conservative">
                            <h2>Conservative</h2>
                            <p>Score: 0/12</p>
                        </div>
                        <canvas id="riskChart" style="max-height: 300px;"></canvas>
                    </div>
                </div>

                <!-- Navigation Buttons -->
                <div style="display: flex; justify-content: space-between; margin-top: 30px;">
                    <button class="calculate-btn" onclick="switchTab(0)" style="background: #6c757d;">
                        <i class="fas fa-arrow-left"></i> Previous: Data Inputs
                    </button>
                    <button class="calculate-btn" onclick="switchTab(2)" style="background: #1e3c72;">
                        Next: Goal Planning <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>

            <!-- Tab 3: Goal Planning -->
            <div class="tab-content" id="tab2">
                <div class="goal-buttons">
                    <button class="goal-tab-btn active" onclick="switchGoalTab(0)">Standard Goals</button>
                    <button class="goal-tab-btn" onclick="switchGoalTab(1)">Retirement Planning</button>
                </div>

                <div class="goal-section active" id="goalSection0">
                    <div class="section">
                        <div class="subtitle">Add New Goal</div>
                        <div class="form-grid">
                            <div class="form-group">
                                <select id="goalType">
                                    <option>Education</option>
                                    <option>Marriage</option>
                                    <option>Wealth Creation</option>
                                    <option>Legacy Planning</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="text" id="goalName" placeholder="Goal Name">
                            </div>
                            <div class="form-group">
                                <input type="text" id="beneficiary" placeholder="Beneficiary">
                            </div>
                            <div class="form-group">
                                <div class="years-input-group">
                                    <input type="number" id="yearsToGoal" value="10">
                                    <span>yrs</span>
                                </div>
                            </div>
                        </div>
                        <div class="form-grid" style="margin-top: 20px;">
                            <div class="form-group">
                                <label>Current Cost (Today)</label>
                                <input type="number" id="currentCost" value="1000000">
                            </div>
                            <div class="form-group">
                                <label>Existing Lumpsum</label>
                                <input type="number" id="existingLumpsum" value="0">
                            </div>
                            <div class="form-group">
                                <label>Current Monthly SIP</label>
                                <input type="number" id="currentSIP" value="0">
                            </div>
                            <div class="form-group">
                                <label>Goal Return Rate (%)</label>
                                <input type="number" id="goalReturnRate" value="12">
                            </div>
                        </div>
                        <button class="calculate-btn" onclick="calculateStandardGoal()">Calculate and Add Goal</button>
                    </div>
                    <div id="standardGoalResults"></div>
                </div>

                <div class="goal-section" id="goalSection1">
                    <div class="section">
                        <div class="subtitle">Retirement Calculator</div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Current Age</label>
                                <input type="number" id="currentAge" value="30" readonly style="background: #f5f5f5;">
                            </div>
                            <div class="form-group">
                                <label>Retirement Age</label>
                                <input type="number" id="retirementAge" value="60">
                            </div>
                            <div class="form-group">
                                <label>Current Monthly Expenses</label>
                                <input type="number" id="currentMonthlyExpenses" value="0">
                            </div>
                            <div class="form-group">
                                <label>Existing Retirement Corpus</label>
                                <input type="number" id="existingRetirementCorpus" value="0">
                            </div>
                            <div class="form-group">
                                <label>Current Retirement SIP</label>
                                <input type="number" id="currentRetirementSIP" value="0">
                            </div>
                            <div class="form-group">
                                <label>Pre-Retirement Return (%)</label>
                                <input type="number" id="preRetirementReturn" value="12">
                            </div>
                        </div>
                        <div class="dynamic-text" id="retirementDynamicText">
                            Calculates corpus required at age 60 to sustain ₹0/mo lifestyle (today's value) until age 85. Post-retirement return assumed: 7%.
                        </div>
                        <button class="calculate-btn" onclick="calculateRetirement()">Calculate & Add Retirement Goal</button>
                    </div>
                    <div id="retirementResults"></div>
                </div>

                <!-- Navigation Buttons -->
                <div style="display: flex; justify-content: space-between; margin-top: 30px;">
                    <button class="calculate-btn" onclick="switchTab(1)" style="background: #6c757d;">
                        <i class="fas fa-arrow-left"></i> Previous: Risk Profiler
                    </button>
                    <button class="calculate-btn" onclick="switchTab(3)" style="background: #1e3c72;">
                        Next: Summary Report <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>

            <!-- Tab 4: Summary Report -->
            <div class="tab-content" id="tab3">
                <div class="summary-grid">
                    <div class="summary-card">
                        <h3>Net Worth</h3>
                        <div class="value" id="netWorth">₹0</div>
                    </div>
                    <div class="summary-card">
                        <h3>Life Insurance Gap</h3>
                        <div class="value" id="lifeInsuranceGap">₹0</div>
                    </div>
                    <div class="summary-card">
                        <h3>Health Insurance Gap</h3>
                        <div class="value" id="healthInsuranceGap">₹0</div>
                    </div>
                    <div class="summary-card">
                        <h3>Emergency Fund Gap</h3>
                        <div class="value" id="emergencyFundGap">₹0</div>
                    </div>
                </div>

                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-shield-alt"></i>
                        Insurance Needs Analysis (HLV)
                    </div>
                    <table class="goal-table">
                        <tr>
                            <td>1. Income Replacement (Living Exp)</td>
                            <td id="incomeReplacement">₹0</td>
                        </tr>
                        <tr>
                            <td>2. Outstanding Liabilities</td>
                            <td id="outstandingLiabilities">₹0</td>
                        </tr>
                        <tr>
                            <td>3. Future Goals (Present Value)</td>
                            <td id="futureGoals">₹0</td>
                        </tr>
                        <tr style="font-weight: 600; background: #f5f7fa;">
                            <td>Total Protection Needs (A)</td>
                            <td id="totalProtection">₹0</td>
                        </tr>
                        <tr>
                            <td>Existing Life Cover</td>
                            <td id="existingLifeCover">₹0</td>
                        </tr>
                        <tr>
                            <td>Liquid Assets (Inv. + Cash)</td>
                            <td id="liquidAssets">₹0</td>
                        </tr>
                        <tr style="font-weight: 600; background: #f5f7fa;">
                            <td>Total Resources (B)</td>
                            <td id="totalResources">₹0</td>
                        </tr>
                        <tr style="font-weight: 600; background: #e3f2fd;">
                            <td>Gap (A - B)</td>
                            <td id="insuranceGap">₹0</td>
                        </tr>
                    </table>
                </div>

                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-chart-pie"></i>
                        Asset Allocation
                    </div>
                    <canvas id="assetChart" style="max-height: 300px;"></canvas>
                </div>

                <div class="section">
                    <div class="section-title">
                        <i class="fas fa-road"></i>
                        Goal Investment Roadmap
                    </div>
                    <table class="goal-table">
                        <thead>
                            <tr>
                                <th>Goal Details</th>
                                <th>Target Corpus</th>
                                <th>Existing Savings</th>
                                <th>Net Gap</th>
                                <th>Add. SIP Needed</th>
                            </tr>
                        </thead>
                        <tbody id="goalRoadmapTable">
                            <tr>
                                <td>Retirement Corpus<br><small>Ben: Self & Spouse • 30 Yrs</small></td>
                                <td>₹1.53 Cr</td>
                                <td>₹300<br><small>Projected Value</small></td>
                                <td>₹1.53 Cr</td>
                                <td>₹4,373/m<br><small>@ 12%</small></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="action-items">
                    <h3>Priority Action Items</h3>
                    <ul id="actionItemsList">
                        <li>Life Insurance coverage is robust.</li>
                        <li>Health Insurance is adequate.</li>
                        <li>Emergency fund is fully funded.</li>
                    </ul>
                </div>

                <div class="ai-section">
                    <h3><i class="fas fa-robot"></i> ARS Fintech AI Advisor</h3>
                    <button class="generate-ai-btn" onclick="generateAIInterpretation()">
                        Generate AI Interpretation
                    </button>
                    <div class="ai-output" id="aiOutput"></div>
                </div>

                <div class="disclaimer">
                    <h4><i class="fas fa-exclamation-triangle"></i> Disclaimer</h4>
                    <p>This report is generated by ARS Kundli - Advance for educational and planning purposes only. The projections are based on assumptions of inflation and investment returns which may vary in reality. Past performance is not indicative of future returns. Please consult with a SEBI Registered Investment Advisor before making any investment decisions. The financial consultant named in this report is responsible for the advice provided.</p>
                </div>

                <!-- Navigation Buttons -->
                <div style="display: flex; justify-content: space-between; margin-top: 30px; align-items: center;">
                    <button class="calculate-btn" onclick="switchTab(2)" style="background: #6c757d;">
                        <i class="fas fa-arrow-left"></i> Previous: Goal Planning
                    </button>
                    <button class="calculate-btn" onclick="saveFinancialPlan()" style="background: #10b981; font-size: 18px; padding: 15px 40px;">
                        <i class="fas fa-save"></i> Save Financial Plan
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let childCount = 0;
        let riskScores = [null, null, null, null];
        let riskChart = null;
        let assetChart = null;
        let goalCharts = [];

        function switchTab(index) {
            const tabs = document.querySelectorAll('.tab-content');
            const navItems = document.querySelectorAll('.nav-item');
            const titles = ['Data Collection', 'Risk Profiler', 'Goal Planning', 'Summary Report'];
            
            tabs.forEach(tab => tab.classList.remove('active'));
            navItems.forEach(nav => nav.classList.remove('active'));
            
            tabs[index].classList.add('active');
            navItems[index].classList.add('active');
            document.getElementById('pageTitle').textContent = titles[index];
            
            if (index === 3) {
                updateSummaryReport();
            }
        }

        function addChild() {
            if (childCount >= 10) {
                alert('Maximum 10 children can be added');
                return;
            }
            
            childCount++;
            const container = document.getElementById('childrenContainer');
            const childDiv = document.createElement('div');
            childDiv.className = 'child-item';
            childDiv.innerHTML = `
                <div style="flex: 1;">
                    <input type="text" placeholder="Child ${childCount} Name" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div style="flex: 1;">
                    <input type="number" placeholder="Age" value="5" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <button class="remove-btn" onclick="removeChild(this)">Remove</button>
            `;
            container.appendChild(childDiv);
        }

        function removeChild(btn) {
            btn.parentElement.remove();
            childCount--;
        }

        function selectRiskOption(question, score, element) {
            const options = element.parentElement.children;
            for (let opt of options) {
                opt.classList.remove('selected');
            }
            element.classList.add('selected');
            riskScores[question] = score;
            updateRiskProfile();
        }

        function updateRiskProfile() {
            const totalScore = riskScores.reduce((a, b) => a + (b || 0), 0);
            const profileDiv = document.getElementById('profileStatus');
            
            let profile, className;
            if (totalScore <= 4) {
                profile = 'Conservative';
                className = 'conservative';
            } else if (totalScore <= 8) {
                profile = 'Moderate';
                className = 'moderate';
            } else {
                profile = 'Aggressive';
                className = 'aggressive';
            }
            
            profileDiv.className = `profile-status ${className}`;
            profileDiv.innerHTML = `<h2>${profile}</h2><p>Score: ${totalScore}/12</p>`;
            
            updateRiskChart(totalScore, profile);
        }

        function updateRiskChart(score, profile) {
            const ctx = document.getElementById('riskChart');
            
            if (riskChart) {
                riskChart.destroy();
            }
            
            riskChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Conservative', 'Moderate', 'Aggressive'],
                    datasets: [{
                        data: profile === 'Conservative' ? [100, 0, 0] : 
                              profile === 'Moderate' ? [30, 70, 0] : [0, 30, 70],
                        backgroundColor: ['#ffc107', '#2196F3', '#f44336']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        function switchGoalTab(index) {
            const sections = document.querySelectorAll('.goal-section');
            const buttons = document.querySelectorAll('.goal-tab-btn');
            
            sections.forEach(s => s.classList.remove('active'));
            buttons.forEach(b => b.classList.remove('active'));
            
            sections[index].classList.add('active');
            buttons[index].classList.add('active');
        }

        function calculateStandardGoal() {
            const goalType = document.getElementById('goalType').value;
            const goalName = document.getElementById('goalName').value || goalType;
            const beneficiary = document.getElementById('beneficiary').value || 'Self';
            const years = parseInt(document.getElementById('yearsToGoal').value);
            const currentCost = parseFloat(document.getElementById('currentCost').value);
            const existingLumpsum = parseFloat(document.getElementById('existingLumpsum').value);
            const currentSIP = parseFloat(document.getElementById('currentSIP').value);
            const returnRate = parseFloat(document.getElementById('goalReturnRate').value) / 100;
            
            const inflationRate = goalType === 'Education' ? 0.10 : 0.06;
            const futureCost = currentCost * Math.pow(1 + inflationRate, years);
            
            const lumpFV = existingLumpsum * Math.pow(1 + returnRate, years);
            const sipMonths = years * 12;
            const monthlyRate = returnRate / 12;
            const sipFV = currentSIP * (Math.pow(1 + monthlyRate, sipMonths) - 1) / monthlyRate * (1 + monthlyRate);
            
            const projectedSavings = lumpFV + sipFV;
            const gap = futureCost - projectedSavings;
            const additionalSIP = gap > 0 ? (gap * monthlyRate) / (Math.pow(1 + monthlyRate, sipMonths) - 1) : 0;
            
            const resultsDiv = document.getElementById('standardGoalResults');
            resultsDiv.innerHTML = `
                <div class="goal-card">
                    <h3>${goalName}</h3>
                    <p><strong>Beneficiary:</strong> ${beneficiary} • <strong>Due in:</strong> ${years} years</p>
                    <table class="goal-table">
                        <tr><td>Target Corpus</td><td>₹${(futureCost/10000000).toFixed(2)} Cr</td></tr>
                        <tr><td>Projected Savings</td><td>₹${(projectedSavings/10000000).toFixed(2)} Cr</td></tr>
                        <tr><td>Gap</td><td>₹${(gap/10000000).toFixed(2)} Cr</td></tr>
                        <tr><td>Additional SIP Needed</td><td>₹${additionalSIP.toFixed(0)}/m</td></tr>
                    </table>
                    <canvas id="goalChart${Date.now()}" class="chart-container"></canvas>
                </div>
            `;
            
            setTimeout(() => {
                const canvas = resultsDiv.querySelector('canvas');
                new Chart(canvas, {
                    type: 'bar',
                    data: {
                        labels: ['Target', 'Projected', 'Gap'],
                        datasets: [{
                            label: 'Amount (₹ Cr)',
                            data: [futureCost/10000000, projectedSavings/10000000, gap/10000000],
                            backgroundColor: ['#2196F3', '#4CAF50', '#f44336']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }, 100);
        }

        function calculateRetirement() {
            const currentAge = parseInt(document.getElementById('currentAge').value);
            const retirementAge = parseInt(document.getElementById('retirementAge').value);
            const monthlyExpenses = parseFloat(document.getElementById('currentMonthlyExpenses').value);
            const existingCorpus = parseFloat(document.getElementById('existingRetirementCorpus').value);
            const currentSIP = parseFloat(document.getElementById('currentRetirementSIP').value);
            const preReturnRate = parseFloat(document.getElementById('preRetirementReturn').value) / 100;
            const postReturnRate = 0.07;
            const lifeExpectancy = 85;
            
            const yearsToRetirement = retirementAge - currentAge;
            const retirementYears = lifeExpectancy - retirementAge;
            
            const inflationRate = 0.06;
            const futureMonthlyExpense = monthlyExpenses * Math.pow(1 + inflationRate, yearsToRetirement);
            const annualExpenseAtRetirement = futureMonthlyExpense * 12;
            
            const requiredCorpus = annualExpenseAtRetirement * retirementYears / postReturnRate;
            
            const lumpFV = existingCorpus * Math.pow(1 + preReturnRate, yearsToRetirement);
            const sipMonths = yearsToRetirement * 12;
            const monthlyRate = preReturnRate / 12;
            const sipFV = currentSIP * (Math.pow(1 + monthlyRate, sipMonths) - 1) / monthlyRate * (1 + monthlyRate);
            
            const projectedSavings = lumpFV + sipFV;
            const gap = requiredCorpus - projectedSavings;
            const additionalSIP = gap > 0 ? (gap * monthlyRate) / (Math.pow(1 + monthlyRate, sipMonths) - 1) : 0;
            
            document.getElementById('retirementDynamicText').textContent = 
                `Calculates corpus required at age ${retirementAge} to sustain ₹${monthlyExpenses.toLocaleString()}/mo lifestyle (today's value) until age ${lifeExpectancy}. Post-retirement return assumed: 7%.`;
            
            const resultsDiv = document.getElementById('retirementResults');
            resultsDiv.innerHTML = `
                <div class="goal-card">
                    <h3>Retirement Corpus</h3>
                    <p><strong>For:</strong> Self & Spouse • <strong>Due in:</strong> ${yearsToRetirement} yrs</p>
                    <table class="goal-table">
                        <tr><td>Existing Lumpsum</td><td>₹${existingCorpus.toLocaleString()}</td></tr>
                        <tr><td>Existing SIP</td><td>₹${currentSIP.toLocaleString()}/m</td></tr>
                        <tr><td>Target Corpus</td><td>₹${(requiredCorpus/10000000).toFixed(2)} Cr</td></tr>
                        <tr><td>Projected Savings</td><td>₹${(projectedSavings/10000000).toFixed(2)} Cr</td></tr>
                        <tr><td>Add. SIP Needed</td><td>₹${additionalSIP.toFixed(0)}/m</td></tr>
                    </table>
                    <h4 style="margin-top: 20px;">Gap Analysis Projection</h4>
                    <canvas id="retirementChart" class="chart-container"></canvas>
                </div>
            `;
            
            setTimeout(() => {
                new Chart(document.getElementById('retirementChart'), {
                    type: 'bar',
                    data: {
                        labels: ['Projected Savings', 'Shortfall (Gap)', 'Retirement Corpus'],
                        datasets: [{
                            label: 'Amount (₹ Cr)',
                            data: [projectedSavings/10000000, gap/10000000, requiredCorpus/10000000],
                            backgroundColor: ['#4CAF50', '#f44336', '#2196F3']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }, 100);
        }

        function updateSummaryReport() {
            const equity = parseFloat(document.getElementById('equity').value) || 0;
            const debt = parseFloat(document.getElementById('debt').value) || 0;
            const realEstate = parseFloat(document.getElementById('realEstate').value) || 0;
            const gold = parseFloat(document.getElementById('gold').value) || 0;
            const cash = parseFloat(document.getElementById('cash').value) || 0;
            
            const homeLoan = parseFloat(document.getElementById('homeLoan').value) || 0;
            const carLoan = parseFloat(document.getElementById('carLoan').value) || 0;
            const otherLoans = parseFloat(document.getElementById('otherLoans').value) || 0;
            
            const totalAssets = equity + debt + realEstate + gold + cash;
            const totalLiabilities = homeLoan + carLoan + otherLoans;
            const netWorth = totalAssets - totalLiabilities;
            
            const monthlyIncome = parseFloat(document.getElementById('monthlyIncome').value) || 0;
            const monthlyExpense = parseFloat(document.getElementById('monthlyExpense').value) || 0;
            const lifeInsurance = parseFloat(document.getElementById('lifeInsurance').value) || 0;
            const healthInsurance = parseFloat(document.getElementById('healthInsurance').value) || 0;
            
            const incomeReplacement = monthlyExpense * 12 * 20;
            const futureGoals = 0;
            const totalProtection = incomeReplacement + totalLiabilities + futureGoals;
            const liquidAssets = equity + debt + cash;
            const totalResources = lifeInsurance + liquidAssets;
            const insuranceGap = totalProtection - totalResources;
            
            const emergencyFund = monthlyExpense * 6;
            const emergencyGap = emergencyFund - cash;
            
            const healthGap = Math.max(0, (500000 * 2) - healthInsurance);
            
            document.getElementById('netWorth').textContent = `₹${(netWorth/100000).toFixed(2)} L`;
            document.getElementById('lifeInsuranceGap').textContent = `₹${(insuranceGap/100000).toFixed(2)} L`;
            document.getElementById('healthInsuranceGap').textContent = `₹${(healthGap/100000).toFixed(2)} L`;
            document.getElementById('emergencyFundGap').textContent = `₹${(emergencyGap/100000).toFixed(2)} L`;
            
            document.getElementById('incomeReplacement').textContent = `₹${(incomeReplacement/100000).toFixed(2)} L`;
            document.getElementById('outstandingLiabilities').textContent = `₹${(totalLiabilities/100000).toFixed(2)} L`;
            document.getElementById('futureGoals').textContent = `₹${(futureGoals/100000).toFixed(2)} L`;
            document.getElementById('totalProtection').textContent = `₹${(totalProtection/100000).toFixed(2)} L`;
            document.getElementById('existingLifeCover').textContent = `₹${(lifeInsurance/100000).toFixed(2)} L`;
            document.getElementById('liquidAssets').textContent = `₹${(liquidAssets/100000).toFixed(2)} L`;
            document.getElementById('totalResources').textContent = `₹${(totalResources/100000).toFixed(2)} L`;
            document.getElementById('insuranceGap').textContent = `₹${(insuranceGap/100000).toFixed(2)} L`;
            
            updateAssetChart(equity, debt, realEstate, gold, cash);
            updateActionItems(insuranceGap, healthGap, emergencyGap);
        }

        function updateAssetChart(equity, debt, realEstate, gold, cash) {
            const ctx = document.getElementById('assetChart');
            
            if (assetChart) {
                assetChart.destroy();
            }
            
            assetChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Equity', 'Debt', 'Real Estate', 'Gold', 'Cash'],
                    datasets: [{
                        data: [equity, debt, realEstate, gold, cash],
                        backgroundColor: ['#2196F3', '#4CAF50', '#FF9800', '#FFC107', '#9C27B0']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        function updateActionItems(lifeGap, healthGap, emergencyGap) {
            const items = [];
            
            if (lifeGap <= 0) {
                items.push('Life Insurance coverage is robust.');
            } else {
                items.push(`Life Insurance gap of ₹${(lifeGap/100000).toFixed(2)} L needs to be covered.`);
            }
            
            if (healthGap <= 0) {
                items.push('Health Insurance is adequate.');
            } else {
                items.push(`Health Insurance gap of ₹${(healthGap/100000).toFixed(2)} L should be addressed.`);
            }
            
            if (emergencyGap <= 0) {
                items.push('Emergency fund is fully funded.');
            } else {
                items.push(`Emergency fund gap of ₹${(emergencyGap/100000).toFixed(2)} L needs attention.`);
            }
            
            const listHTML = items.map(item => `<li>${item}</li>`).join('');
            document.getElementById('actionItemsList').innerHTML = listHTML;
        }

        function generateAIInterpretation() {
            const output = document.getElementById('aiOutput');
            output.style.display = 'block';
            output.innerHTML = '<p style="text-align: center;"><i class="fas fa-spinner fa-spin"></i> Generating AI interpretation...</p>';
            
            setTimeout(() => {
                output.innerHTML = `
                    <h4 style="margin-bottom: 15px;">Financial Health Analysis</h4>
                    <p><strong>Overall Assessment:</strong> Your financial profile shows a balanced approach with room for optimization. Here are key insights:</p>
                    <ul style="margin: 15px 0; line-height: 1.8;">
                        <li><strong>Net Worth:</strong> Your current asset base provides a solid foundation for wealth building.</li>
                        <li><strong>Insurance Coverage:</strong> Review your life and health insurance to ensure adequate protection for your family.</li>
                        <li><strong>Goal Planning:</strong> Your retirement planning is on track, but consider increasing SIPs for faster goal achievement.</li>
                        <li><strong>Risk Profile:</strong> Based on your responses, a diversified portfolio aligned with your risk tolerance is recommended.</li>
                        <li><strong>Action Priority:</strong> Focus on building emergency fund and closing insurance gaps before aggressive investing.</li>
                    </ul>
                    <p><strong>Recommendation:</strong> Schedule a detailed review with a SEBI registered advisor to create a comprehensive financial plan tailored to your specific needs and goals.</p>
                `;
            }, 2000);
        }

        // Initialize risk chart on load
        window.addEventListener('load', function() {
            updateRiskChart(0, 'Conservative');
        });

        // Save Financial Plan Function
        function saveFinancialPlan() {
            // Validate required fields
            const fullName = document.getElementById('fullName').value;
            if (!fullName) {
                alert('Please enter Full Name before saving');
                switchTab(0);
                document.getElementById('fullName').focus();
                return;
            }

            // Collect all form data
            const formData = {
                full_name: fullName,
                age: document.getElementById('age').value || null,
                dob: document.getElementById('dob').value || null,
                email: document.getElementById('email').value || null,
                contact: document.getElementById('contact').value || null,
                dependents: document.getElementById('dependents').value || 0,
                spouse_name: document.getElementById('spouseName').value || null,
                spouse_age: document.getElementById('spouseAge').value || null,
                monthly_income: document.getElementById('monthlyIncome').value || 0,
                monthly_expense: document.getElementById('monthlyExpense').value || 0,
                life_insurance: document.getElementById('lifeInsurance').value || 0,
                health_insurance: document.getElementById('healthInsurance').value || 0,
                equity: document.getElementById('equity').value || 0,
                debt: document.getElementById('debt').value || 0,
                real_estate: document.getElementById('realEstate').value || 0,
                gold: document.getElementById('gold').value || 0,
                cash: document.getElementById('cash').value || 0,
                home_loan: document.getElementById('homeLoan').value || 0,
                car_loan: document.getElementById('carLoan').value || 0,
                other_loans: document.getElementById('otherLoans').value || 0,
                general_inflation: document.getElementById('generalInflation').value || 6,
                education_inflation: document.getElementById('educationInflation').value || 10,
                inv_return: document.getElementById('invReturn').value || 12,
                post_retirement_return: document.getElementById('postRetirementReturn').value || 7,
                life_expectancy: document.getElementById('lifeExpectancy').value || 85,
            };

            // Collect children data
            const childrenData = [];
            const childItems = document.querySelectorAll('.child-item');
            childItems.forEach(item => {
                const nameInput = item.querySelector('input[type="text"]');
                const ageInput = item.querySelector('input[type="number"]');
                if (nameInput && ageInput) {
                    childrenData.push({
                        name: nameInput.value,
                        age: ageInput.value
                    });
                }
            });
            formData.children_data = childrenData;

            // Collect risk profile
            const totalScore = riskScores.reduce((a, b) => a + (b || 0), 0);
            let riskProfile = 'Conservative';
            if (totalScore > 8) riskProfile = 'Aggressive';
            else if (totalScore > 4) riskProfile = 'Moderate';
            
            formData.risk_profile = riskProfile;
            formData.risk_score = totalScore;

            // Show loading
            const saveBtn = event.target;
            const originalText = saveBtn.innerHTML;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            saveBtn.disabled = true;

            // Send AJAX request
            fetch('<?php echo e(route("financial-plan.store")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Financial Plan saved successfully!');
                    // Redirect to success page
                    window.location.href = `/financial-plan/${data.id}`;
                } else {
                    alert('Error: ' + (data.message || 'Failed to save financial plan'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while saving the financial plan');
            })
            .finally(() => {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
            });
        }
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/kundli-complete.blade.php ENDPATH**/ ?>