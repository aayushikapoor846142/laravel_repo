<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
</head>
<body>
    <h1>Products List</h1>
    <p>Total products: <?php echo e($products->total()); ?></p>
    
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="border: 1px solid #ccc; padding: 10px; margin: 10px 0;">
            <h2><?php echo e($product->name); ?></h2>
            <p>SKU: <?php echo e($product->sku); ?></p>
            <p>Price: $<?php echo e($product->price); ?></p>
            <p>Stock: <?php echo e($product->stock); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php echo e($products->links()); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\t_task\resources\views/products/simple.blade.php ENDPATH**/ ?>