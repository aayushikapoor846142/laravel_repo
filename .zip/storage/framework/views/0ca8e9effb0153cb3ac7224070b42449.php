<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Contacts</h5>
                    <a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg"></i> Add Contact
                    </a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <div class="mb-4">
                        <form id="searchForm" class="row g-3">
                            <div class="col-md-7">
                                <input type="text" name="search" class="form-control" placeholder="Search by name, email, or phone..." 
                                       value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-3">
                                <select name="status" class="form-select">
                                    <option value="">All Statuses</option>
                                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                                    <option value="merged" <?php echo e(request('status') == 'merged' ? 'selected' : ''); ?>>Merged</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Search
                                </button>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Company</th>
                                    <th>Status</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <?php if($contact->profile_image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $contact->profile_image)); ?>" 
                                                         alt="<?php echo e($contact->full_name); ?>" 
                                                         class="rounded-circle me-2" 
                                                         style="width: 32px; height: 32px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="d-flex align-items-center justify-content-center bg-light rounded-circle me-2" 
                                                         style="width: 32px; height: 32px;">
                                                        <i class="bi bi-person" style="font-size: 1rem; color: #6c757d;"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div>
                                                    <div><?php echo e($contact->full_name); ?></div>
                                                    <?php if($contact->job_title): ?>
                                                        <small class="text-muted"><?php echo e($contact->job_title); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($contact->email ?? '-'); ?></td>
                                        <td><?php echo e($contact->phone ?? '-'); ?></td>
                                        <td><?php echo e($contact->company ?? '-'); ?></td>
                                        <td>
                                            <?php if($contact->is_merged): ?>
                                                <span class="badge bg-secondary">Merged</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('contacts.show', $contact->id)); ?>" 
                                                   class="btn btn-sm btn-outline-primary"
                                                   title="View">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('contacts.edit', $contact->id)); ?>" 
                                                   class="btn btn-sm btn-outline-secondary"
                                                   title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="<?php echo e(route('contacts.merge.show', $contact->id)); ?>" 
                                                   class="btn btn-sm btn-outline-info"
                                                   title="Merge">
                                                    <i class="bi bi-arrow-left-right"></i>
                                                </a>
                                                <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" 
                                                      method="POST" 
                                                      class="d-inline" 
                                                      onsubmit="return confirm('Are you sure you want to delete this contact?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">
                                            <div class="py-4">
                                                <i class="bi bi-person-x" style="font-size: 2rem; color: #6c757d;"></i>
                                                <p class="mt-2 mb-0">No contacts found</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($contacts->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($contacts->withQueryString()->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle search form submission
        const searchForm = document.getElementById('searchForm');
        if (searchForm) {
            searchForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(searchForm);
                const params = new URLSearchParams(formData).toString();
                window.location.href = '<?php echo e(route('contacts.index')); ?>?' + params;
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/contacts/index.blade.php ENDPATH**/ ?>