

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h4>Merge Contacts</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('contacts.merge.store', $contact)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5>Master Contact (Will be kept)</h5>
                                <?php echo $__env->make('contacts.partials.contact-card', ['contact' => $contact], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="secondary_contact_id">Select Contact to Merge</label>
                                    <select name="secondary_contact_id" id="secondary_contact_id" class="form-control" required>
                                        <option value="">Select a contact to merge</option>
                                        <?php $__currentLoopData = $potentialDuplicates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duplicate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($duplicate->id); ?>">
                                                <?php echo e($duplicate->full_name); ?> (<?php echo e($duplicate->email); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                                <div id="merge-preview" class="mt-3" style="display: none;">
                                    <h5>Merge Preview</h5>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label>Name:</label>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="name" value="master" checked>
                                                    <label class="form-check-label">
                                                        <?php echo e($contact->full_name); ?>

                                                    </label>
                                                </div>
                                            </div>
                                            
                                            <h6 class="mt-3">Custom Fields:</h6>
                                            <div id="custom-fields-preview"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($potentialDuplicates->isEmpty()): ?>
                            <div class="alert alert-info mt-2">
                                <p>No potential duplicates found based on:</p>
                                <ul>
                                    <li>Email: <?php echo e($contact->email ?: 'Not available'); ?></li>
                                    <li>Phone: <?php echo e($contact->phone ?: 'Not available'); ?></li>
                                    <li>Name: <?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('contacts.show', $contact)); ?>" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Confirm Merge</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const secondaryContactSelect = document.getElementById('secondary_contact_id');
        const mergePreview = document.getElementById('merge-preview');
        
        secondaryContactSelect.addEventListener('change', function() {
            const contactId = this.value;
            
            if (contactId) {
                fetch(`/api/contacts/${contactId}`)
                    .then(response => response.json())
                    .then(contact => {
                        updateMergePreview(contact);
                        mergePreview.style.display = 'block';
                    });
            } else {
                mergePreview.style.display = 'none';
            }
        });
        
        function updateMergePreview(contact) {
            const customFieldsPreview = document.getElementById('custom-fields-preview');
            customFieldsPreview.innerHTML = '';
            
            if (contact.custom_fields && contact.custom_fields.length > 0) {
                contact.custom_fields.forEach(field => {
                    const fieldDiv = document.createElement('div');
                    fieldDiv.className = 'form-group';
                    fieldDiv.innerHTML = `
                        <label>${field.definition.field_name}:</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   name="keep_fields[]" 
                                   value="${field.definition.field_name}"
                                   id="field-${field.id}">
                            <label class="form-check-label" for="field-${field.id}">
                                ${field.value}
                            </label>
                        </div>
                    `;
                    customFieldsPreview.appendChild(fieldDiv);
                });
            } else {
                customFieldsPreview.innerHTML = '<p>No custom fields to merge.</p>';
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/contacts/merge/index.blade.php ENDPATH**/ ?>