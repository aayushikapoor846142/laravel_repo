<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Merge Contacts</h5>
                    <a href="<?php echo e(route('contacts.show', $master->id)); ?>" class="btn btn-sm btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Back to Contact
                    </a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <?php if($duplicate): ?>
                        
                        <form id="mergeForm" action="<?php echo e(route('contacts.merge.process', $master->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="duplicate_id" value="<?php echo e($duplicate->id); ?>">
                            
                            <div class="row">
                                
                                <div class="col-md-6">
                                    <div class="card mb-4 border-primary">
                                        <div class="card-header bg-primary text-white">
                                            <h6 class="mb-0">Master Contact (Will be kept)</h6>
                                        </div>
                                        <div class="card-body">
                                            <?php echo $__env->make('contacts.partials.contact_details', ['contact' => $master, 'prefix' => 'master'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-md-6">
                                    <div class="card mb-4">
                                        <div class="card-header bg-secondary text-white">
                                            <h6 class="mb-0">Duplicate Contact (Will be merged)</h6>
                                        </div>
                                        <div class="card-body">
                                            <?php echo $__env->make('contacts.partials.contact_details', ['contact' => $duplicate, 'prefix' => 'duplicate'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0">Select Fields to Keep</h6>
                                    <small class="text-muted">Choose which contact's information to keep for each field.</small>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Field</th>
                                                    <th class="text-center">Master</th>
                                                    <th class="text-center">Duplicate</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $standardFields = [
                                                        'first_name' => 'First Name',
                                                        'last_name' => 'Last Name',
                                                        'email' => 'Email',
                                                        'phone' => 'Phone',
                                                        'company' => 'Company',
                                                        'job_title' => 'Job Title',
                                                        'address' => 'Address',
                                                        'city' => 'City',
                                                        'state' => 'State',
                                                        'postal_code' => 'Postal Code',
                                                        'country' => 'Country',
                                                        'notes' => 'Notes',
                                                    ];
                                                ?>

                                                
                                                <?php $__currentLoopData = $standardFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(!empty($master->$field) || !empty($duplicate->$field)): ?>
                                                        <tr>
                                                            <td><?php echo e($label); ?></td>
                                                            <td class="text-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" 
                                                                           name="keep_fields[<?php echo e($field); ?>]" 
                                                                           id="keep_master_<?php echo e($field); ?>" 
                                                                           value="master" 
                                                                           <?php echo e(empty($duplicate->$field) || !empty($master->$field) ? 'checked' : ''); ?>>
                                                                    <label class="form-check-label" for="keep_master_<?php echo e($field); ?>">
                                                                        <?php echo e($master->$field ?? '(empty)'); ?>

                                                                    </label>
                                                                </div>
                                                            </td>
                                                            <td class="text-center">
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" 
                                                                           name="keep_fields[<?php echo e($field); ?>]" 
                                                                           id="keep_duplicate_<?php echo e($field); ?>" 
                                                                           value="duplicate"
                                                                           <?php echo e(!empty($duplicate->$field) && empty($master->$field) ? 'checked' : ''); ?>>
                                                                    <label class="form-check-label" for="keep_duplicate_<?php echo e($field); ?>">
                                                                        <?php echo e($duplicate->$field ?? '(empty)'); ?>

                                                                    </label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <?php
                                                    $allCustomFields = collect($master->customFields)
                                                        ->concat($duplicate->customFields)
                                                        ->unique('field_name')
                                                        ->sortBy('field_name');
                                                ?>

                                                <?php $__currentLoopData = $allCustomFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $masterValue = $master->customFields->firstWhere('field_name', $field->field_name);
                                                        $duplicateValue = $duplicate->customFields->firstWhere('field_name', $field->field_name);
                                                    ?>
                                                    <tr>
                                                        <td><?php echo e($field->field_name); ?></td>
                                                        <td class="text-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" 
                                                                       name="custom_fields[<?php echo e($field->field_name); ?>]" 
                                                                       id="keep_master_cf_<?php echo e($field->id); ?>" 
                                                                       value="master" 
                                                                       <?php echo e(!$duplicateValue || ($masterValue && !$duplicateValue) ? 'checked' : ''); ?>>
                                                                <label class="form-check-label" for="keep_master_cf_<?php echo e($field->id); ?>">
                                                                    <?php echo e($masterValue ? $masterValue->field_value : '(empty)'); ?>

                                                                </label>
                                                            </div>
                                                        </td>
                                                        <td class="text-center">
                                                            <?php if($duplicateValue): ?>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" 
                                                                           name="custom_fields[<?php echo e($field->field_name); ?>]" 
                                                                           id="keep_duplicate_cf_<?php echo e($field->id); ?>" 
                                                                           value="duplicate"
                                                                           <?php echo e(!$masterValue && $duplicateValue ? 'checked' : ''); ?>>
                                                                    <label class="form-check-label" for="keep_duplicate_cf_<?php echo e($field->id); ?>">
                                                                        <?php echo e($duplicateValue->field_value); ?>

                                                                    </label>
                                                                </div>
                                                            <?php else: ?>
                                                                <span class="text-muted">(empty)</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between">
                                <a href="<?php echo e(route('contacts.merge.show', $master->id)); ?>" class="btn btn-outline-secondary">
                                    <i class="bi bi-arrow-left"></i> Back to Merge Selection
                                </a>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#confirmMergeModal">
                                    <i class="bi bi-arrow-merge"></i> Confirm Merge
                                </button>
                            </div>

                            <!-- Confirmation Modal -->
                            <div class="modal fade" id="confirmMergeModal" tabindex="-1" aria-labelledby="confirmMergeModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-warning">
                                            <h5 class="modal-title" id="confirmMergeModalLabel">Confirm Merge</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to merge these contacts? This action cannot be undone.</p>
                                            <div class="alert alert-warning">
                                                <i class="bi bi-exclamation-triangle-fill"></i>
                                                The duplicate contact will be marked as merged and will no longer appear in search results.
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="bi bi-arrow-merge"></i> Merge Contacts
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    <?php else: ?>
                        
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0">Select Duplicate to Merge</h6>
                                <small class="text-muted">The following contacts might be duplicates of <?php echo e($master->full_name); ?>.</small>
                            </div>
                            <div class="card-body">
                                <?php if($potentialDuplicates->count() > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Phone</th>
                                                    <th>Company</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $potentialDuplicates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duplicate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($duplicate->full_name); ?></td>
                                                        <td><?php echo e($duplicate->email); ?></td>
                                                        <td><?php echo e($duplicate->phone); ?></td>
                                                        <td><?php echo e($duplicate->company); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('contacts.merge.with', ['contact' => $master->id, 'duplicate' => $duplicate->id])); ?>" 
                                                               class="btn btn-sm btn-outline-primary">
                                                                <i class="bi bi-arrow-left-right"></i> Merge with this contact
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info mb-0">
                                        <i class="bi bi-info-circle"></i>
                                        No potential duplicates found for this contact.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end">
                            <a href="<?php echo e(route('contacts.show', $master->id)); ?>" class="btn btn-secondary">
                                <i class="bi bi-x"></i> Cancel
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include any necessary JavaScript -->
<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle form submission with AJAX
        const form = document.getElementById('mergeForm');
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(form);
                
                // Show loading state
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalBtnText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Merging...';
                
                // Submit form via AJAX
                fetch(form.action, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(Object.fromEntries(formData.entries()))
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show success message and redirect
                        const successAlert = `
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="bi bi-check-circle-fill"></i> ${data.message}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        `;
                        
                        // Insert alert at the top of the card body
                        const cardBody = document.querySelector('.card-body');
                        cardBody.insertAdjacentHTML('afterbegin', successAlert);
                        
                        // Redirect after a short delay
                        setTimeout(() => {
                            window.location.href = data.redirect;
                        }, 1500);
                    } else {
                        // Show error message
                        const errorAlert = `
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="bi bi-exclamation-triangle-fill"></i> ${data.message || 'An error occurred while merging contacts.'}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        `;
                        
                        // Insert alert at the top of the card body
                        const cardBody = document.querySelector('.card-body');
                        cardBody.insertAdjacentHTML('afterbegin', errorAlert);
                        
                        // Re-enable submit button
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalBtnText;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    
                    // Show error message
                    const errorAlert = `
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill"></i> An unexpected error occurred. Please try again.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    `;
                    
                    // Insert alert at the top of the card body
                    const cardBody = document.querySelector('.card-body');
                    cardBody.insertAdjacentHTML('afterbegin', errorAlert);
                    
                    // Re-enable submit button
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnText;
                });
            });
        }
        
        // Toggle radio buttons when clicking on table rows
        document.querySelectorAll('table tbody tr').forEach(row => {
            row.addEventListener('click', (e) => {
                // Only trigger if the click wasn't on a link, button, or input
                if (!e.target.closest('a') && !e.target.closest('button') && !e.target.closest('input')) {
                    const radio = row.querySelector('input[type="radio"]:not(:checked)');
                    if (radio) {
                        radio.checked = true;
                        // Trigger change event in case any listeners are attached
                        radio.dispatchEvent(new Event('change'));
                    }
                }
            });
            
            // Add hover effect
            row.style.cursor = 'pointer';
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/contacts/merge.blade.php ENDPATH**/ ?>