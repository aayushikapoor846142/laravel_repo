<div class="card">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($contact->full_name); ?></h5>
        <?php if($contact->email): ?>
            <p class="mb-1"><i class="bi bi-envelope"></i> <?php echo e($contact->email); ?></p>
        <?php endif; ?>
        <?php if($contact->phone): ?>
            <p class="mb-1"><i class="bi bi-telephone"></i> <?php echo e($contact->phone); ?></p>
        <?php endif; ?>
        <?php if($contact->address): ?>
            <p class="mb-1"><i class="bi bi-geo-alt"></i> <?php echo e($contact->address); ?></p>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/contacts/partials/contact-card.blade.php ENDPATH**/ ?>