
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Financial Health Assessment - ARS Fintech</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .header p {
            font-size: 14px;
            opacity: 0.9;
        }

        .main-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            padding: 30px;
        }

        .left-panel, .right-panel {
            padding: 20px;
        }

        .left-panel {
            border-right: 2px solid #e5e7eb;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #374151;
            font-size: 14px;
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e5e7eb;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 60px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 700;
            color: #667eea;
            margin: 25px 0 15px 0;
            padding-bottom: 8px;
            border-bottom: 2px solid #667eea;
        }

        .calculate-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-top: 20px;
        }

        .calculate-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .calculate-btn:active {
            transform: translateY(0);
        }

        .results-container {
            display: block;
        }

        .score-cards {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }

        .score-card {
            background: #f9fafb;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }

        .score-card.overall {
            grid-column: 1 / -1;
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            border-left: 4px solid #764ba2;
        }

        .score-card h3 {
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .score-card .value {
            font-size: 28px;
            font-weight: 700;
            color: #1f2937;
        }

        .score-card .value.low {
            color: #10b981;
        }

        .score-card .value.medium {
            color: #f59e0b;
        }

        .score-card .value.high {
            color: #ef4444;
        }

        .chart-container {
            background: #f9fafb;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            height: 300px;
        }

        .recommendations {
            background: #eff6ff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border-left: 4px solid #3b82f6;
        }

        .recommendations h3 {
            color: #1e40af;
            margin-bottom: 10px;
            font-size: 16px;
        }

        .recommendations p {
            color: #1e3a8a;
            font-size: 14px;
            line-height: 1.6;
        }

        .table-container {
            overflow-x: auto;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        table th {
            background: #f3f4f6;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid #e5e7eb;
        }

        table td {
            padding: 12px;
            border-bottom: 1px solid #e5e7eb;
        }

        table tr:hover {
            background: #f9fafb;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-adequate {
            background: #d1fae5;
            color: #065f46;
        }

        .status-partial {
            background: #fef3c7;
            color: #92400e;
        }

        .status-major {
            background: #fee2e2;
            color: #991b1b;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .action-btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .print-btn {
            background: #10b981;
            color: white;
        }

        .print-btn:hover {
            background: #059669;
        }

        .disclaimer {
            text-align: center;
            padding: 20px;
            background: #fef3c7;
            color: #92400e;
            font-size: 12px;
            border-top: 2px solid #fbbf24;
        }

        @media (max-width: 968px) {
            .main-content {
                grid-template-columns: 1fr;
            }

            .left-panel {
                border-right: none;
                border-bottom: 2px solid #e5e7eb;
            }
        }

        @media print {
            body {
                background: white;
                padding: 0;
            }

            .left-panel, .calculate-btn, .action-buttons {
                display: none !important;
            }

            .main-content {
                grid-template-columns: 1fr;
            }

            .right-panel {
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Business Financial Health Assessment</h1>
            <p>by ARS Fintech (https://www.arsfintech.org/business-fhc)</p>
        </div>

        <div class="main-content">
            <!-- LEFT PANEL - INPUTS -->
            <form action="<?php echo e(route('business-fhc.store')); ?>" method="POST" id="businessForm">
            <?php echo csrf_field(); ?>
            <div class="left-panel">
                <h2 class="section-title">Advisor Information</h2>
                
                <div class="form-group">
                    <label>Advisor / Firm Name</label>
                    <input type="text" name="advisor_name" id="advisorName" placeholder="Enter advisor name" required>
                </div>

                <div class="form-group">
                    <label>Advisor Contact</label>
                    <input type="text" name="advisor_contact" id="advisorContact" placeholder="Enter contact details" required>
                </div>

                <h2 class="section-title">Business Information</h2>

                <div class="form-group">
                    <label>Business / Client Name</label>
                    <input type="text" name="business_name" id="businessName" placeholder="Enter business name" required>
                </div>

                <div class="form-group">
                    <label>Owner / Contact Person</label>
                    <input type="text" name="owner_name" id="ownerName" placeholder="Enter owner name" required>
                </div>

                <div class="form-group">
                    <label>Type of Business</label>
                    <select name="business_type" id="businessType" required>
                        <option value="Proprietorship">Proprietorship</option>
                        <option value="Partnership">Partnership</option>
                        <option value="Pvt. Ltd.">Pvt. Ltd.</option>
                        <option value="LLP">LLP</option>
                        <option value="SME / Other">SME / Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Number of Partners / Directors</label>
                    <input type="number" name="num_partners" id="numPartners" value="1" min="1" required>
                </div>

                <div class="form-group">
                    <label>Annual Turnover (₹)</label>
                    <input type="number" name="turnover" id="turnover" placeholder="Enter annual turnover" required>
                </div>

                <div class="form-group">
                    <label>Net Profit (₹)</label>
                    <input type="number" name="net_profit" id="netProfit" placeholder="Enter net profit" required>
                </div>

                <div class="form-group">
                    <label>Number of Employees</label>
                    <input type="number" name="num_employees" id="numEmployees" value="0" min="0" required>
                </div>

                <div class="form-group">
                    <label>Report Footer Note (optional)</label>
                    <textarea name="footer_note" id="footerNote" placeholder="Add any additional notes"></textarea>
                </div>

                <h2 class="section-title">Existing Insurance Covers (₹ Total)</h2>

                <div class="form-group">
                    <label>Keyman Insurance</label>
                    <input type="number" name="existing_keyman" id="existingKeyman" value="0" min="0">
                </div>

                <div class="form-group">
                    <label>Partnership / Shareholder Protection</label>
                    <input type="number" name="existing_partnership" id="existingPartnership" value="0" min="0">
                </div>

                <div class="form-group">
                    <label>Group Health (Total Sum Insured)</label>
                    <input type="number" name="existing_group_health" id="existingGroupHealth" value="0" min="0">
                </div>

                <div class="form-group">
                    <label>Fire / Asset Insurance</label>
                    <input type="number" name="existing_fire" id="existingFire" value="0" min="0">
                </div>

                <div class="form-group">
                    <label>Liability Insurance</label>
                    <input type="number" name="existing_liability" id="existingLiability" value="0" min="0">
                </div>

                <button type="button" class="calculate-btn" onclick="calculateAndSave()">Calculate & Save Assessment</button>

                <div style="margin-top: 20px; padding: 15px; background: #eff6ff; border-radius: 6px; font-size: 12px; color: #1e40af;">
                    <strong>Tip:</strong> Adjust the assumptions inside code if your market norms differ (e.g., Group Health per-employee cover).
                </div>
            </div>
            </form>

            <!-- RIGHT PANEL - RESULTS -->
            <div class="right-panel">
                <div id="resultsContainer" class="results-container">
                    <h2 class="section-title">Results & Recommendations</h2>

                    <div class="score-cards">
                        <div class="score-card overall">
                            <h3>Overall Score</h3>
                            <div class="value low" id="overallScore">LOW</div>
                        </div>
                        <div class="score-card">
                            <h3>Major Gaps (≥50%)</h3>
                            <div class="value" id="majorGaps">0</div>
                        </div>
                        <div class="score-card">
                            <h3>Partial Gaps (20–49%)</h3>
                            <div class="value" id="partialGaps">0</div>
                        </div>
                        <div class="score-card">
                            <h3>Adequate Areas</h3>
                            <div class="value" id="adequateAreas">5</div>
                        </div>
                        <div class="score-card">
                            <h3>Risk Score (0–15)</h3>
                            <div class="value" id="riskScore">0</div>
                        </div>
                    </div>

                    <div class="chart-container">
                        <canvas id="adequacyChart"></canvas>
                    </div>

                    <div class="recommendations">
                        <h3>Actionable Recommendations</h3>
                        <p id="recommendationText">All categories appear adequate at current assumptions. Review annually or upon turnover/profit change.</p>
                    </div>

                    <h3 class="section-title">Detailed Table</h3>
                    <div class="table-container">
                        <table id="resultsTable">
                            <thead>
                                <tr>
                                    <th>Category</th>
                                    <th>Recommended (₹)</th>
                                    <th>Existing (₹)</th>
                                    <th>Gap (₹)</th>
                                    <th>Adequacy %</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody id="tableBody">
                                <tr>
                                    <td><strong>Keyman Insurance</strong></td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>100%</td>
                                    <td><span class="status-badge status-adequate">Adequate</span></td>
                                </tr>
                                <tr>
                                    <td><strong>Partnership / Shareholder Protection</strong></td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>100%</td>
                                    <td><span class="status-badge status-adequate">Adequate</span></td>
                                </tr>
                                <tr>
                                    <td><strong>Group Health (Total)</strong></td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>100%</td>
                                    <td><span class="status-badge status-adequate">Adequate</span></td>
                                </tr>
                                <tr>
                                    <td><strong>Fire / Asset</strong></td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>100%</td>
                                    <td><span class="status-badge status-adequate">Adequate</span></td>
                                </tr>
                                <tr>
                                    <td><strong>Liability</strong></td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>₹0</td>
                                    <td>100%</td>
                                    <td><span class="status-badge status-adequate">Adequate</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="action-buttons">
                        <button class="action-btn print-btn" onclick="window.print()">Print / Save PDF</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="disclaimer">
            This report is an educational guide and not a legal opinion.
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
        let chartInstance = null;
        let savedAssessmentId = null;

        // Initialize chart on page load
        window.addEventListener('load', function() {
            initializeChart();
        });

        function initializeChart() {
            const ctx = document.getElementById('adequacyChart').getContext('2d');
            
            const defaultCategories = [
                'Keyman Insurance',
                'Partnership / Shareholder Protection',
                'Group Health (Total)',
                'Fire / Asset',
                'Liability'
            ];

            chartInstance = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: defaultCategories,
                    datasets: [{
                        label: 'Adequacy %',
                        data: [100, 100, 100, 100, 100],
                        backgroundColor: ['#10b981', '#10b981', '#10b981', '#10b981', '#10b981'],
                        borderRadius: 6,
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'Adequacy: ' + context.parsed.y.toFixed(1) + '%';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        },
                        x: {
                            ticks: {
                                font: {
                                    size: 10
                                }
                            }
                        }
                    }
                }
            });
        }

        function formatCurrency(num) {
            if (num >= 10000000) {
                return '₹' + (num / 10000000).toFixed(2) + ' Cr';
            } else if (num >= 100000) {
                return '₹' + (num / 100000).toFixed(2) + ' L';
            } else if (num >= 1000) {
                return '₹' + (num / 1000).toFixed(2) + ' K';
            }
            return '₹' + num.toFixed(0);
        }

        function calculateAndSave() {
            // Validate required fields
            const form = document.getElementById('businessForm');
            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }

            // Get form data
            const formData = new FormData(form);
            
            // Show loading state
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = 'Saving...';
            btn.disabled = true;

            // Submit via AJAX
            fetch('<?php echo e(route("business-fhc.store")); ?>', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    savedAssessmentId = data.id;
                    // Display results
                    displayResults(data.results);
                    // Show success message
                    alert('Assessment saved successfully!');
                    // Add view report button
                    addViewReportButton(data.id);
                } else {
                    alert('Error: ' + (data.message || 'Failed to save assessment'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while saving the assessment');
            })
            .finally(() => {
                btn.textContent = originalText;
                btn.disabled = false;
            });
        }

        function displayResults(results) {
            const categories = results.categories;
            
            // Update score cards
            document.getElementById('overallScore').textContent = results.overall_score;
            document.getElementById('overallScore').className = 'value ' + results.overall_score.toLowerCase();
            document.getElementById('majorGaps').textContent = results.major_gaps;
            document.getElementById('partialGaps').textContent = results.partial_gaps;
            document.getElementById('adequateAreas').textContent = results.adequate_areas;
            document.getElementById('riskScore').textContent = results.risk_score;

            // Generate recommendations
            let recommendation = '';
            if (results.major_gaps > 0) {
                recommendation = `Critical: ${results.major_gaps} major gap(s) identified. Immediate attention required for categories with less than 50% adequacy. `;
            }
            if (results.partial_gaps > 0) {
                recommendation += `${results.partial_gaps} partial gap(s) found. Consider improving coverage in categories between 50-80% adequacy. `;
            }
            if (results.major_gaps === 0 && results.partial_gaps === 0) {
                recommendation = 'All categories appear adequate at current assumptions. Review annually or upon turnover/profit change.';
            }
            document.getElementById('recommendationText').textContent = recommendation;

            // Update table
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = '';
            categories.forEach(cat => {
                let status = 'Adequate';
                let statusClass = 'status-adequate';
                if (cat.adequacy < 50) {
                    status = 'Major Gap';
                    statusClass = 'status-major';
                } else if (cat.adequacy < 80) {
                    status = 'Partial Gap';
                    statusClass = 'status-partial';
                }

                const row = `
                    <tr>
                        <td><strong>${cat.name}</strong></td>
                        <td>${formatCurrency(cat.recommended)}</td>
                        <td>${formatCurrency(cat.existing)}</td>
                        <td>${formatCurrency(cat.gap)}</td>
                        <td>${cat.adequacy.toFixed(0)}%</td>
                        <td><span class="status-badge ${statusClass}">${status}</span></td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });

            // Update chart
            updateChart(categories);

            // Show results
            document.getElementById('resultsContainer').classList.add('active');
            document.querySelector('.right-panel').scrollIntoView({ behavior: 'smooth' });
        }

        function addViewReportButton(assessmentId) {
            const actionButtons = document.querySelector('.action-buttons');
            if (!document.getElementById('viewReportBtn')) {
                const viewBtn = document.createElement('a');
                viewBtn.id = 'viewReportBtn';
                viewBtn.href = `/business-fhc/${assessmentId}`;
                viewBtn.className = 'action-btn print-btn';
                viewBtn.textContent = 'View Full Report';
                viewBtn.style.background = '#667eea';
                actionButtons.insertBefore(viewBtn, actionButtons.firstChild);
            }
        }

        function calculateAssessment() {
            const turnover = parseFloat(document.getElementById('turnover').value) || 0;
            const profit = parseFloat(document.getElementById('netProfit').value) || 0;
            const employees = parseInt(document.getElementById('numEmployees').value) || 0;
            const partners = parseInt(document.getElementById('numPartners').value) || 1;

            // Calculate recommended amounts based on advisory logic
            const keymanRec = Math.max(profit * 0.5, turnover * 0.2);
            const partnershipRec = partners > 1 ? profit * 3 : 0;
            const groupHealthRec = employees * 500000;
            const fireRec = turnover * 0.3;
            const liabilityRec = turnover * 0.1;

            // Get existing amounts
            const existingKeyman = parseFloat(document.getElementById('existingKeyman').value) || 0;
            const existingPartnership = parseFloat(document.getElementById('existingPartnership').value) || 0;
            const existingGroupHealth = parseFloat(document.getElementById('existingGroupHealth').value) || 0;
            const existingFire = parseFloat(document.getElementById('existingFire').value) || 0;
            const existingLiability = parseFloat(document.getElementById('existingLiability').value) || 0;

            // Calculate gaps and adequacy
            const categories = [
                {
                    name: 'Keyman Insurance',
                    recommended: keymanRec,
                    existing: existingKeyman,
                    gap: Math.max(0, keymanRec - existingKeyman),
                    adequacy: keymanRec > 0 ? Math.min(100, (existingKeyman / keymanRec) * 100) : 100
                },
                {
                    name: 'Partnership / Shareholder Protection',
                    recommended: partnershipRec,
                    existing: existingPartnership,
                    gap: Math.max(0, partnershipRec - existingPartnership),
                    adequacy: partnershipRec > 0 ? Math.min(100, (existingPartnership / partnershipRec) * 100) : 100
                },
                {
                    name: 'Group Health (Total)',
                    recommended: groupHealthRec,
                    existing: existingGroupHealth,
                    gap: Math.max(0, groupHealthRec - existingGroupHealth),
                    adequacy: groupHealthRec > 0 ? Math.min(100, (existingGroupHealth / groupHealthRec) * 100) : 100
                },
                {
                    name: 'Fire / Asset',
                    recommended: fireRec,
                    existing: existingFire,
                    gap: Math.max(0, fireRec - existingFire),
                    adequacy: fireRec > 0 ? Math.min(100, (existingFire / fireRec) * 100) : 100
                },
                {
                    name: 'Liability',
                    recommended: liabilityRec,
                    existing: existingLiability,
                    gap: Math.max(0, liabilityRec - existingLiability),
                    adequacy: liabilityRec > 0 ? Math.min(100, (existingLiability / liabilityRec) * 100) : 100
                }
            ];

            // Calculate statistics
            const majorGaps = categories.filter(c => c.adequacy < 50).length;
            const partialGaps = categories.filter(c => c.adequacy >= 50 && c.adequacy < 80).length;
            const adequateAreas = categories.filter(c => c.adequacy >= 80).length;
            
            const avgAdequacy = categories.reduce((sum, c) => sum + c.adequacy, 0) / categories.length;
            const riskScore = Math.round((100 - avgAdequacy) * 0.15);
            
            let overallScore = 'HIGH';
            let overallClass = 'high';
            if (avgAdequacy >= 80) {
                overallScore = 'LOW';
                overallClass = 'low';
            } else if (avgAdequacy >= 50) {
                overallScore = 'MEDIUM';
                overallClass = 'medium';
            }

            // Update UI
            document.getElementById('overallScore').textContent = overallScore;
            document.getElementById('overallScore').className = 'value ' + overallClass;
            document.getElementById('majorGaps').textContent = majorGaps;
            document.getElementById('partialGaps').textContent = partialGaps;
            document.getElementById('adequateAreas').textContent = adequateAreas;
            document.getElementById('riskScore').textContent = riskScore;

            // Generate recommendations
            let recommendation = '';
            if (majorGaps > 0) {
                recommendation = `Critical: ${majorGaps} major gap(s) identified. Immediate attention required for categories with less than 50% adequacy. `;
            }
            if (partialGaps > 0) {
                recommendation += `${partialGaps} partial gap(s) found. Consider improving coverage in categories between 50-80% adequacy. `;
            }
            if (majorGaps === 0 && partialGaps === 0) {
                recommendation = 'All categories appear adequate at current assumptions. Review annually or upon turnover/profit change.';
            }
            document.getElementById('recommendationText').textContent = recommendation;

            // Update table
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = '';
            categories.forEach(cat => {
                let status = 'Adequate';
                let statusClass = 'status-adequate';
                if (cat.adequacy < 50) {
                    status = 'Major Gap';
                    statusClass = 'status-major';
                } else if (cat.adequacy < 80) {
                    status = 'Partial Gap';
                    statusClass = 'status-partial';
                }

                const row = `
                    <tr>
                        <td><strong>${cat.name}</strong></td>
                        <td>${formatCurrency(cat.recommended)}</td>
                        <td>${formatCurrency(cat.existing)}</td>
                        <td>${formatCurrency(cat.gap)}</td>
                        <td>${cat.adequacy.toFixed(0)}%</td>
                        <td><span class="status-badge ${statusClass}">${status}</span></td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });

            // Update chart
            updateChart(categories);

            // Show results
            document.getElementById('resultsContainer').classList.add('active');
            document.querySelector('.right-panel').scrollIntoView({ behavior: 'smooth' });
        }

        function updateChart(categories) {
            const ctx = document.getElementById('adequacyChart').getContext('2d');
            
            if (chartInstance) {
                chartInstance.destroy();
            }

            const colors = categories.map(c => {
                if (c.adequacy >= 80) return '#10b981';
                if (c.adequacy >= 50) return '#f59e0b';
                return '#ef4444';
            });

            chartInstance = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: categories.map(c => c.name),
                    datasets: [{
                        label: 'Adequacy %',
                        data: categories.map(c => c.adequacy),
                        backgroundColor: colors,
                        borderRadius: 6,
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'Adequacy: ' + context.parsed.y.toFixed(1) + '%';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        },
                        x: {
                            ticks: {
                                font: {
                                    size: 10
                                }
                            }
                        }
                    }
                }
            });
        }
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/business-fhc.blade.php ENDPATH**/ ?>