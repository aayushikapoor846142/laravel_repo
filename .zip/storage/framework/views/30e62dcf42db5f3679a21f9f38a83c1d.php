

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Contact Details</h5>
                    <div>
                        <a href="<?php echo e(route('contacts.edit', $contact->id)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                        <?php if(!$contact->is_merged): ?>
                            <a href="<?php echo e(route('contacts.merge.index', $contact)); ?>" 
                            class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-merge"></i> Merge
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Back to Contacts
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <!-- Left Column - Contact Info -->
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-6">
                                    <h4><?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></h4>
                                    <?php if($contact->email): ?>
                                        <p class="mb-1">
                                            <i class="bi bi-envelope me-2"></i>
                                            <a href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a>
                                        </p>
                                    <?php endif; ?>
                                    <?php if($contact->phone): ?>
                                        <p class="mb-1">
                                            <i class="bi bi-telephone me-2"></i>
                                            <a href="tel:<?php echo e($contact->phone); ?>"><?php echo e($contact->phone); ?></a>
                                        </p>
                                    <?php endif; ?>
                                    <?php if($contact->address): ?>
                                        <p class="mb-1">
                                            <i class="bi bi-geo-alt me-2"></i>
                                            <?php echo e($contact->address); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if($contact->profile_image || $contact->document): ?>
                                <div class="col-md-6">
                                    <?php if($contact->profile_image): ?>
                                        <div class="mb-3">
                                            <h6>Profile Image</h6>
                                            <img src="<?php echo e(asset('storage/' . $contact->profile_image)); ?>" 
                                                 alt="Profile Image" 
                                                 class="img-thumbnail" 
                                                 style="max-width: 200px;">
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if($contact->document): ?>
                                        <div>
                                            <h6>Document</h6>
                                            <a href="<?php echo e(asset('storage/' . $contact->document)); ?>" 
                                               class="btn btn-sm btn-outline-secondary"
                                               target="_blank">
                                                <i class="bi bi-file-earmark-text"></i> View Document
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>

                            <!-- Custom Fields Section -->
                            <?php if($customFields->isNotEmpty()): ?>
                                <hr>
                                <h5>Additional Information</h5>
                                <div class="row">
                                    <?php $__currentLoopData = $customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($field->value)): ?>
                                            <div class="col-md-6 mb-3">
                                                <strong><?php echo e($field->definition->field_name); ?>:</strong>
                                                <div>
                                                    <?php if(is_array($field->formatted_value)): ?>
                                                        <?php echo e(implode(', ', $field->formatted_value)); ?>

                                                    <?php else: ?>
                                                        <?php echo nl2br(e($field->formatted_value)); ?>

                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Right Column - Merge History -->
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Merge History</h6>
                                </div>
                                <div class="card-body">
                                    <?php if($contact->mergeHistory->isNotEmpty() || $contact->mergedFrom->isNotEmpty()): ?>
                                        <div class="list-group list-group-flush">
                                            <?php $__currentLoopData = $contact->mergeHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="list-group-item">
                                                    <div class="d-flex w-100 justify-content-between">
                                                        <small class="text-muted"><?php echo e($merge->created_at->diffForHumans()); ?></small>
                                                    </div>
                                                    <p class="mb-1">Merged contact #<?php echo e($merge->mergedContact->id); ?> into this contact</p>
                                                    <small class="text-muted">Merged by: <?php echo e($merge->mergedBy->name ?? 'System'); ?></small>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php $__currentLoopData = $contact->mergedFrom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="list-group-item">
                                                    <div class="d-flex w-100 justify-content-between">
                                                        <small class="text-muted"><?php echo e($merge->created_at->diffForHumans()); ?></small>
                                                    </div>
                                                    <p class="mb-1">This contact was merged into contact #<?php echo e($merge->masterContact->id); ?></p>
                                                    <small class="text-muted">Merged by: <?php echo e($merge->mergedBy->name ?? 'System'); ?></small>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-muted mb-0">No merge history found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-footer d-flex justify-content-between">
                    <div>
                        <span class="text-muted">Created: <?php echo e($contact->created_at->format('M j, Y')); ?></span>
                        <?php if($contact->created_at != $contact->updated_at): ?>
                            <span class="text-muted ms-3">Updated: <?php echo e($contact->updated_at->format('M j, Y')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this contact?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </form>
                        <a href="<?php echo e(route('contacts.merge.show', $contact->id)); ?>" class="btn btn-sm btn-outline-primary ms-2">
                            <i class="bi bi-merge"></i> Merge Contact
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .img-thumbnail {
        max-height: 200px;
        object-fit: cover;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/contacts/show.blade.php ENDPATH**/ ?>