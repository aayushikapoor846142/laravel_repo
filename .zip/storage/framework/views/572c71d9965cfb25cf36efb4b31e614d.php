
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARS Fintech Kundli</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }

        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .header p {
            font-size: 16px;
            opacity: 0.95;
        }

        .form-content {
            padding: 40px 30px;
        }

        .section {
            margin-bottom: 35px;
        }

        .section-title {
            font-size: 20px;
            color: #667eea;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
            font-weight: 600;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 14px;
            color: #333;
            margin-bottom: 8px;
            font-weight: 500;
        }

        input, select {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: white;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        input:hover, select:hover {
            border-color: #667eea;
        }

        .submit-section {
            text-align: center;
            margin-top: 40px;
        }

        .submit-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 50px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .note {
            text-align: center;
            font-size: 13px;
            color: #666;
            margin-top: 25px;
            font-style: italic;
        }

        @media (max-width: 600px) {
            .header h1 {
                font-size: 22px;
            }

            .header p {
                font-size: 14px;
            }

            .form-content {
                padding: 30px 20px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>ARS Fintech Kundli - Decoding your Money Blueprint</h1>
            <p>Comprehensive Financial Planning Calculation & Report</p>
        </div>

        <div class="form-content">
            <form id="financialForm" action="<?php echo e(route('kundli.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <!-- Client Information Section -->
                <div class="section">
                    <h2 class="section-title">Client Information</h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="dob">Date of Birth</label>
                            <input type="date" id="dob" name="dob" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="contact">Contact Number</label>
                            <input type="tel" id="contact" name="contact" required>
                        </div>
                        <div class="form-group">
                            <label for="profile">Profile</label>
                            <input type="text" id="profile" name="profile" placeholder="e.g., Self-employed, Salaried">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="spouse_name">Spouse Name</label>
                            <input type="text" id="spouse_name" name="spouse_name">
                        </div>
                        <div class="form-group">
                            <label for="spouse_profile">Spouse Profile</label>
                            <input type="text" id="spouse_profile" name="spouse_profile" placeholder="e.g., Homemaker, Working">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="dependents">Total Dependents</label>
                            <input type="number" id="dependents" name="dependents" min="0" value="0">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="child1_name">Child 1 Name</label>
                            <input type="text" id="child1_name" name="child1_name">
                        </div>
                        <div class="form-group">
                            <label for="child1_age">Child 1 Age</label>
                            <input type="number" id="child1_age" name="child1_age" min="0" max="100">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="child2_name">Child 2 Name</label>
                            <input type="text" id="child2_name" name="child2_name">
                        </div>
                        <div class="form-group">
                            <label for="child2_age">Child 2 Age</label>
                            <input type="number" id="child2_age" name="child2_age" min="0" max="100">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="other_info">Other Information</label>
                            <input type="text" id="other_info" name="other_info" placeholder="Any additional details">
                        </div>
                    </div>
                </div>

                <!-- Financial Advisor Information Section -->
                <div class="section">
                    <h2 class="section-title">Financial Advisor Information</h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="advisor_name">Advisor Name</label>
                            <input type="text" id="advisor_name" name="advisor_name" required>
                        </div>
                        <div class="form-group">
                            <label for="advisor_contact">Contact Number</label>
                            <input type="tel" id="advisor_contact" name="advisor_contact" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="certifications">Certifications</label>
                            <input type="text" id="certifications" name="certifications" placeholder="e.g., CFP, CFA">
                        </div>
                        <div class="form-group">
                            <label for="website">Website</label>
                            <input type="url" id="website" name="website" placeholder="https://example.com">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">City</label>
                            <input type="text" id="city" name="city" required>
                        </div>
                    </div>
                </div>

                <!-- Submit Section -->
                <div class="submit-section">
                    <button type="submit" class="submit-btn">Start Financial Planning</button>
                    <p class="note">Note: All information is strictly confidential and used only for personalized planning.</p>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Add input validation for phone numbers
        const phoneInputs = document.querySelectorAll('input[type="tel"]');
        phoneInputs.forEach(input => {
            input.addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9+\-() ]/g, '');
            });
        });
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\crm-task\resources\views/kundli-form.blade.php ENDPATH**/ ?>