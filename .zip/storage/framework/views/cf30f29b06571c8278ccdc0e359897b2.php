

<?php $__env->startSection('title', 'Upload Images'); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 py-6 sm:px-0">
    <div class="bg-white shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">
                Upload Product Images
            </h3>
            
            <div x-data="imageUploader()" class="space-y-6">
                <!-- Product Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Select Product
                    </label>
                    <select x-model="selectedProductId" 
                            class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                        <option value="">Choose a product...</option>
                        <?php $__currentLoopData = \App\Models\Product::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->sku); ?> - <?php echo e($product->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Drag and Drop Area -->
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition"
                     @dragover.prevent="dragover = true"
                     @dragleave.prevent="dragover = false"
                     @drop.prevent="handleDrop($event)"
                     :class="{ 'border-blue-500 bg-blue-50': dragover }">
                    
                    <svg class="mx-auto h-16 w-16 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    
                    <div class="mt-4">
                        <label for="image-file" class="cursor-pointer">
                            <span class="mt-2 block text-sm font-medium text-gray-900">
                                Drop image here or click to browse
                            </span>
                            <input id="image-file" 
                                   type="file" 
                                   accept="image/*"
                                   class="hidden" 
                                   @change="handleFileSelect($event)">
                        </label>
                        <p class="mt-1 text-xs text-gray-500">PNG, JPG, GIF up to 50MB</p>
                    </div>
                </div>

                <!-- Upload Queue -->
                <div x-show="uploads.length > 0" class="space-y-3">
                    <h4 class="text-sm font-medium text-gray-900">Upload Queue</h4>
                    
                    <template x-for="upload in uploads" :key="upload.id">
                        <div class="bg-gray-50 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-2">
                                <div class="flex items-center flex-1">
                                    <img :src="upload.preview" class="h-12 w-12 object-cover rounded" />
                                    <div class="ml-3 flex-1">
                                        <p class="text-sm font-medium text-gray-900" x-text="upload.name"></p>
                                        <p class="text-xs text-gray-500" x-text="formatFileSize(upload.size)"></p>
                                    </div>
                                </div>
                                <div class="ml-4">
                                    <span x-show="upload.status === 'pending'" class="px-2 py-1 text-xs font-medium text-gray-600 bg-gray-200 rounded">
                                        Pending
                                    </span>
                                    <span x-show="upload.status === 'uploading'" class="px-2 py-1 text-xs font-medium text-blue-600 bg-blue-100 rounded">
                                        Uploading
                                    </span>
                                    <span x-show="upload.status === 'processing'" class="px-2 py-1 text-xs font-medium text-yellow-600 bg-yellow-100 rounded">
                                        Processing
                                    </span>
                                    <span x-show="upload.status === 'completed'" class="px-2 py-1 text-xs font-medium text-green-600 bg-green-100 rounded">
                                        ✓ Completed
                                    </span>
                                    <span x-show="upload.status === 'error'" class="px-2 py-1 text-xs font-medium text-red-600 bg-red-100 rounded">
                                        Error
                                    </span>
                                </div>
                            </div>
                            
                            <!-- Progress Bar -->
                            <div x-show="upload.status === 'uploading' || upload.status === 'processing'" class="mt-2">
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                                         :style="`width: ${upload.progress}%`"></div>
                                </div>
                                <p class="text-xs text-gray-600 mt-1" x-text="`${upload.progress}% - ${upload.statusText}`"></p>
                            </div>

                            <!-- Error Message -->
                            <div x-show="upload.error" class="mt-2 text-xs text-red-600" x-text="upload.error"></div>

                            <!-- Generated Variants -->
                            <div x-show="upload.variants && upload.variants.length > 0" class="mt-3">
                                <p class="text-xs text-gray-600 mb-2">Generated variants:</p>
                                <div class="flex space-x-2">
                                    <template x-for="variant in upload.variants" :key="variant.id">
                                        <div class="text-center">
                                            <div class="w-16 h-16 bg-gray-200 rounded flex items-center justify-center">
                                                <span class="text-xs text-gray-600" x-text="variant.variant"></span>
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </template>
                </div>

                <!-- Upload Button -->
                <div x-show="uploads.length > 0 && !uploading">
                    <button @click="startUpload()" 
                            :disabled="!selectedProductId"
                            class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed">
                        Upload Images
                    </button>
                    <p x-show="!selectedProductId" class="mt-2 text-sm text-red-600 text-center">
                        Please select a product first
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function imageUploader() {
    return {
        selectedProductId: '',
        uploads: [],
        dragover: false,
        uploading: false,
        chunkSize: 512 * 1024, // 512KB chunks

        handleDrop(e) {
            this.dragover = false;
            const files = e.dataTransfer.files;
            this.addFiles(files);
        },

        handleFileSelect(e) {
            const files = e.target.files;
            this.addFiles(files);
            e.target.value = '';
        },

        addFiles(files) {
            Array.from(files).forEach(file => {
                if (file.type.startsWith('image/')) {
                    const upload = {
                        id: Date.now() + Math.random(),
                        file: file,
                        name: file.name,
                        size: file.size,
                        preview: URL.createObjectURL(file),
                        status: 'pending',
                        progress: 0,
                        statusText: '',
                        error: null,
                        uploadId: null,
                        variants: []
                    };
                    this.uploads.push(upload);
                }
            });
        },

        formatFileSize(bytes) {
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            if (bytes === 0) return '0 Bytes';
            const i = Math.floor(Math.log(bytes) / Math.log(1024));
            return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
        },

        async startUpload() {
            if (!this.selectedProductId) return;
            
            this.uploading = true;

            for (const upload of this.uploads) {
                if (upload.status === 'completed') continue;
                
                try {
                    await this.uploadFile(upload);
                } catch (error) {
                    upload.status = 'error';
                    upload.error = error.message;
                }
            }

            this.uploading = false;
        },

        async uploadFile(upload) {
            upload.status = 'uploading';
            upload.statusText = 'Calculating checksum...';

            // Calculate checksum
            const checksum = await this.calculateChecksum(upload.file);
            
            // Calculate chunks
            const totalChunks = Math.ceil(upload.file.size / this.chunkSize);
            
            upload.statusText = 'Initializing upload...';

            // Initialize upload
            const initResponse = await fetch('<?php echo e(route("api.uploads.initialize")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({
                    filename: upload.file.name,
                    mime_type: upload.file.type,
                    total_size: upload.file.size,
                    total_chunks: totalChunks,
                    checksum: checksum
                })
            });

            const initData = await initResponse.json();
            if (!initResponse.ok) throw new Error(initData.error || 'Failed to initialize upload');
            
            upload.uploadId = initData.upload_id;

            // Upload chunks
            for (let i = 0; i < totalChunks; i++) {
                const start = i * this.chunkSize;
                const end = Math.min(start + this.chunkSize, upload.file.size);
                const chunk = upload.file.slice(start, end);
                
                upload.statusText = `Uploading chunk ${i + 1}/${totalChunks}...`;
                upload.progress = Math.round((i / totalChunks) * 80);

                const chunkData = await this.fileToBase64(chunk);

                const chunkResponse = await fetch(`/api/uploads/${upload.uploadId}/chunk`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({
                        chunk_index: i,
                        chunk_data: chunkData
                    })
                });

                if (!chunkResponse.ok) {
                    const errorData = await chunkResponse.json();
                    throw new Error(errorData.error || 'Failed to upload chunk');
                }
            }

            upload.progress = 85;
            upload.statusText = 'Completing upload...';

            // Complete upload
            const completeResponse = await fetch(`/api/uploads/${upload.uploadId}/complete`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!completeResponse.ok) {
                const errorData = await completeResponse.json();
                throw new Error(errorData.error || 'Failed to complete upload');
            }

            upload.progress = 90;
            upload.status = 'processing';
            upload.statusText = 'Generating image variants...';

            // Attach to product and generate variants
            const attachResponse = await fetch(`/api/uploads/${upload.uploadId}/attach-product`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({
                    product_id: this.selectedProductId,
                    set_as_primary: this.uploads.indexOf(upload) === 0
                })
            });

            const attachData = await attachResponse.json();
            if (!attachResponse.ok) throw new Error(attachData.error || 'Failed to attach image');

            upload.progress = 100;
            upload.status = 'completed';
            upload.statusText = 'Complete!';
            upload.variants = attachData.images || [];
        },

        async calculateChecksum(file) {
            const buffer = await file.arrayBuffer();
            const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        },

        async fileToBase64(blob) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = () => {
                    const base64 = reader.result.split(',')[1];
                    resolve(base64);
                };
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        }
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\t_task\resources\views/products/upload.blade.php ENDPATH**/ ?>