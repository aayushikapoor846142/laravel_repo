<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Business FHC Assessments</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 28px;
            font-weight: 600;
        }

        .btn {
            padding: 12px 24px;
            background: white;
            color: #667eea;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .content {
            padding: 30px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #667eea;
            border-bottom: 2px solid #667eea;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }

        tr:hover {
            background: #f8f9fa;
        }

        .action-link {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        .score-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .score-low {
            background: #d1fae5;
            color: #065f46;
        }

        .score-medium {
            background: #fef3c7;
            color: #92400e;
        }

        .score-high {
            background: #fee2e2;
            color: #991b1b;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }

        .empty-state h2 {
            font-size: 24px;
            margin-bottom: 15px;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Business FHC Assessments</h1>
            <a href="<?php echo e(route('business-fhc.create')); ?>" class="btn">+ New Assessment</a>
        </div>

        <div class="content">
            <?php if($assessments->count() > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Business Name</th>
                            <th>Owner</th>
                            <th>Advisor</th>
                            <th>Overall Score</th>
                            <th>Risk Score</th>
                            <th>Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($assessment->id); ?></td>
                            <td><?php echo e($assessment->business_name); ?></td>
                            <td><?php echo e($assessment->owner_name); ?></td>
                            <td><?php echo e($assessment->advisor_name); ?></td>
                            <td>
                                <span class="score-badge score-<?php echo e(strtolower($assessment->overall_score)); ?>">
                                    <?php echo e($assessment->overall_score); ?>

                                </span>
                            </td>
                            <td><?php echo e($assessment->risk_score); ?>/15</td>
                            <td><?php echo e($assessment->created_at->format('d M, Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('business-fhc.show', $assessment->id)); ?>" class="action-link">View Report</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top: 30px;">
                <?php echo e($assessments->links()); ?>

            </div>
            <?php else: ?>
            <div class="empty-state">
                <h2>No Assessments Found</h2>
                <p>Start by creating your first business financial health check</p>
                <a href="<?php echo e(route('business-fhc.create')); ?>" class="btn" style="margin-top: 20px;">Create First Assessment</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\crm-task\resources\views/business-fhc-index.blade.php ENDPATH**/ ?>