<?php

namespace YourVendor\UserDiscounts\Tests\Unit;

use YourVendor\UserDiscounts\Tests\TestCase;
use YourVendor\UserDiscounts\DiscountService;
use YourVendor\UserDiscounts\Models\Discount;
use YourVendor\UserDiscounts\Models\UserDiscount;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Event;
use YourVendor\UserDiscounts\Events\DiscountAssigned;
use YourVendor\UserDiscounts\Events\DiscountRevoked;
use YourVendor\UserDiscounts\Events\DiscountApplied;

class DiscountServiceTest extends TestCase
{
    use RefreshDatabase;

    private DiscountService $service;
    private $user;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->service = new DiscountService();
        
        // Create a simple user model for testing
        $this->user = new class {
            public $id = 1;
        };
    }

    public function test_assign_creates_user_discount(): void
    {
        Event::fake();

        $discount = Discount::create([
            'code' => 'TEST10',
            'name' => 'Test Discount',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $userDiscount = $this->service->assign($this->user, $discount);

        $this->assertInstanceOf(UserDiscount::class, $userDiscount);
        $this->assertEquals($this->user->id, $userDiscount->user_id);
        $this->assertEquals($discount->id, $userDiscount->discount_id);
        $this->assertNull($userDiscount->revoked_at);

        Event::assertDispatched(DiscountAssigned::class);
    }

    public function test_assign_is_idempotent(): void
    {
        $discount = Discount::create([
            'code' => 'TEST10',
            'name' => 'Test Discount',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $first = $this->service->assign($this->user, $discount);
        $second = $this->service->assign($this->user, $discount);

        $this->assertEquals($first->id, $second->id);
        $this->assertEquals(1, UserDiscount::count());
    }

    public function test_revoke_marks_discount_as_revoked(): void
    {
        Event::fake();

        $discount = Discount::create([
            'code' => 'TEST10',
            'name' => 'Test Discount',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $discount);
        $result = $this->service->revoke($this->user, $discount);

        $this->assertTrue($result);
        
        $userDiscount = UserDiscount::first();
        $this->assertNotNull($userDiscount->revoked_at);

        Event::assertDispatched(DiscountRevoked::class);
    }

    public function test_eligible_for_returns_active_discounts(): void
    {
        $activeDiscount = Discount::create([
            'code' => 'ACTIVE',
            'name' => 'Active Discount',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $expiredDiscount = Discount::create([
            'code' => 'EXPIRED',
            'name' => 'Expired Discount',
            'type' => 'percentage',
            'value' => 20,
            'is_active' => true,
            'expires_at' => now()->subDay(),
        ]);

        $this->service->assign($this->user, $activeDiscount);
        $this->service->assign($this->user, $expiredDiscount);

        $eligible = $this->service->eligibleFor($this->user);

        $this->assertCount(1, $eligible);
        $this->assertEquals('ACTIVE', $eligible[0]->code);
    }

    public function test_apply_calculates_percentage_discount(): void
    {
        Event::fake();

        $discount = Discount::create([
            'code' => 'SAVE10',
            'name' => '10% Off',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $discount);

        $result = $this->service->apply($this->user, 100.00);

        $this->assertEquals(100.00, $result['original_amount']);
        $this->assertEquals(10.00, $result['discount_amount']);
        $this->assertEquals(90.00, $result['final_amount']);
        $this->assertCount(1, $result['applied_discounts']);

        Event::assertDispatched(DiscountApplied::class);
    }

    public function test_apply_calculates_fixed_discount(): void
    {
        $discount = Discount::create([
            'code' => 'SAVE15',
            'name' => '$15 Off',
            'type' => 'fixed',
            'value' => 15,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $discount);

        $result = $this->service->apply($this->user, 100.00);

        $this->assertEquals(100.00, $result['original_amount']);
        $this->assertEquals(15.00, $result['discount_amount']);
        $this->assertEquals(85.00, $result['final_amount']);
    }

    public function test_apply_stacks_multiple_discounts(): void
    {
        $percentage = Discount::create([
            'code' => 'SAVE10',
            'name' => '10% Off',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $fixed = Discount::create([
            'code' => 'SAVE5',
            'name' => '$5 Off',
            'type' => 'fixed',
            'value' => 5,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $percentage);
        $this->service->assign($this->user, $fixed);

        config(['user-discounts.stacking_order' => 'percentage_first']);

        $result = $this->service->apply($this->user, 100.00);

        // 10% of 100 = 10, then $5 off 90 = 85
        $this->assertEquals(100.00, $result['original_amount']);
        $this->assertEquals(15.00, $result['discount_amount']);
        $this->assertEquals(85.00, $result['final_amount']);
        $this->assertCount(2, $result['applied_discounts']);
    }

    public function test_apply_respects_max_percentage_cap(): void
    {
        $discount1 = Discount::create([
            'code' => 'SAVE60',
            'name' => '60% Off',
            'type' => 'percentage',
            'value' => 60,
            'is_active' => true,
        ]);

        $discount2 = Discount::create([
            'code' => 'SAVE50',
            'name' => '50% Off',
            'type' => 'percentage',
            'value' => 50,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $discount1);
        $this->service->assign($this->user, $discount2);

        config(['user-discounts.max_percentage_cap' => 80]);

        $result = $this->service->apply($this->user, 100.00);

        // Only first discount applied (60%), second would exceed 80% cap
        $this->assertEquals(60.00, $result['discount_amount']);
        $this->assertCount(1, $result['applied_discounts']);
    }

    public function test_apply_is_deterministic(): void
    {
        $discount1 = Discount::create([
            'code' => 'SAVE10',
            'name' => '10% Off',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $discount2 = Discount::create([
            'code' => 'SAVE5',
            'name' => '$5 Off',
            'type' => 'fixed',
            'value' => 5,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $discount1);
        $this->service->assign($this->user, $discount2);

        // Apply multiple times with same amount
        $result1 = $this->service->apply($this->user, 100.00);
        
        // Reset usage counts for second test
        UserDiscount::query()->update(['usage_count' => 0]);
        
        $result2 = $this->service->apply($this->user, 100.00);

        $this->assertEquals($result1['final_amount'], $result2['final_amount']);
        $this->assertEquals($result1['discount_amount'], $result2['discount_amount']);
    }

    public function test_apply_enforces_per_user_usage_limit(): void
    {
        $discount = Discount::create([
            'code' => 'ONETIME',
            'name' => 'One Time Use',
            'type' => 'percentage',
            'value' => 10,
            'max_uses_per_user' => 1,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $discount);

        // First application should work
        $result1 = $this->service->apply($this->user, 100.00);
        $this->assertEquals(10.00, $result1['discount_amount']);

        // Second application should not apply discount
        $result2 = $this->service->apply($this->user, 100.00);
        $this->assertEquals(0.00, $result2['discount_amount']);
    }

    public function test_apply_is_idempotent_with_same_parameters(): void
    {
        $discount = Discount::create([
            'code' => 'TEST10',
            'name' => 'Test Discount',
            'type' => 'percentage',
            'value' => 10,
            'is_active' => true,
        ]);

        $this->service->assign($this->user, $discount);

        // Reset to test idempotency
        UserDiscount::query()->update(['usage_count' => 0]);
        Discount::query()->update(['current_uses' => 0]);

        $result1 = $this->service->apply($this->user, 100.00);
        
        UserDiscount::query()->update(['usage_count' => 0]);
        Discount::query()->update(['current_uses' => 0]);
        
        $result2 = $this->service->apply($this->user, 100.00);

        $this->assertEquals($result1, $result2);
    }
}
