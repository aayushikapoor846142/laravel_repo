<?php

namespace YourVendor\UserDiscounts;

use Illuminate\Support\Facades\DB;
use YourVendor\UserDiscounts\Models\Discount;
use YourVendor\UserDiscounts\Models\UserDiscount;
use YourVendor\UserDiscounts\Models\DiscountAudit;
use YourVendor\UserDiscounts\Events\DiscountAssigned;
use YourVendor\UserDiscounts\Events\DiscountRevoked;
use YourVendor\UserDiscounts\Events\DiscountApplied;

class DiscountService
{
    public function assign($user, Discount $discount): UserDiscount
    {
        $userDiscount = UserDiscount::firstOrCreate(
            [
                'user_id' => $user->id,
                'discount_id' => $discount->id,
            ],
            [
                'assigned_at' => now(),
                'usage_count' => 0,
            ]
        );

        // If previously revoked, un-revoke it
        if ($userDiscount->revoked_at) {
            $userDiscount->update(['revoked_at' => null]);
        }

        DiscountAudit::create([
            'user_id' => $user->id,
            'discount_id' => $discount->id,
            'action' => 'assigned',
            'created_at' => now(),
        ]);

        event(new DiscountAssigned($user, $discount));

        return $userDiscount;
    }

    public function revoke($user, Discount $discount): bool
    {
        $userDiscount = UserDiscount::where('user_id', $user->id)
            ->where('discount_id', $discount->id)
            ->first();

        if (!$userDiscount || $userDiscount->isRevoked()) {
            return false;
        }

        $userDiscount->update(['revoked_at' => now()]);

        DiscountAudit::create([
            'user_id' => $user->id,
            'discount_id' => $discount->id,
            'action' => 'revoked',
            'created_at' => now(),
        ]);

        event(new DiscountRevoked($user, $discount));

        return true;
    }

    public function eligibleFor($user): array
    {
        return UserDiscount::with('discount')
            ->where('user_id', $user->id)
            ->whereNull('revoked_at')
            ->get()
            ->filter(fn($ud) => $ud->canUse())
            ->map(fn($ud) => $ud->discount)
            ->values()
            ->all();
    }

    public function apply($user, float $amount, ?array $discountIds = null): array
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('Amount must be greater than zero');
        }

        $eligibleDiscounts = $this->getEligibleDiscounts($user, $discountIds);

        if (empty($eligibleDiscounts)) {
            return [
                'original_amount' => $amount,
                'discount_amount' => 0.0,
                'final_amount' => $amount,
                'applied_discounts' => [],
            ];
        }

        $sortedDiscounts = $this->sortDiscountsByStackingOrder($eligibleDiscounts);

        return DB::transaction(function () use ($user, $amount, $sortedDiscounts) {
            return $this->applyDiscounts($user, $amount, $sortedDiscounts);
        });
    }

    private function getEligibleDiscounts($user, ?array $discountIds): array
    {
        $query = UserDiscount::with('discount')
            ->where('user_id', $user->id)
            ->whereNull('revoked_at');

        if ($discountIds !== null) {
            $query->whereIn('discount_id', $discountIds);
        }

        return $query->get()
            ->filter(fn($ud) => $ud->canUse())
            ->map(fn($ud) => [
                'user_discount' => $ud,
                'discount' => $ud->discount,
            ])
            ->values()
            ->all();
    }

    private function sortDiscountsByStackingOrder(array $discounts): array
    {
        $order = config('user-discounts.stacking_order', 'percentage_first');

        return match ($order) {
            'percentage_first' => $this->sortPercentageFirst($discounts),
            'fixed_first' => $this->sortFixedFirst($discounts),
            'highest_first' => $this->sortHighestFirst($discounts),
            default => $discounts,
        };
    }

    private function sortPercentageFirst(array $discounts): array
    {
        usort($discounts, function ($a, $b) {
            if ($a['discount']->type === 'percentage' && $b['discount']->type === 'fixed') {
                return -1;
            }
            if ($a['discount']->type === 'fixed' && $b['discount']->type === 'percentage') {
                return 1;
            }
            return $b['discount']->value <=> $a['discount']->value;
        });
        return $discounts;
    }

    private function sortFixedFirst(array $discounts): array
    {
        usort($discounts, function ($a, $b) {
            if ($a['discount']->type === 'fixed' && $b['discount']->type === 'percentage') {
                return -1;
            }
            if ($a['discount']->type === 'percentage' && $b['discount']->type === 'fixed') {
                return 1;
            }
            return $b['discount']->value <=> $a['discount']->value;
        });
        return $discounts;
    }

    private function sortHighestFirst(array $discounts): array
    {
        usort($discounts, fn($a, $b) => $b['discount']->value <=> $a['discount']->value);
        return $discounts;
    }

    private function applyDiscounts($user, float $amount, array $sortedDiscounts): array
    {
        $originalAmount = $amount;
        $currentAmount = $amount;
        $totalDiscountAmount = 0.0;
        $appliedDiscounts = [];
        $totalPercentage = 0.0;
        $maxPercentageCap = config('user-discounts.max_percentage_cap', 100);

        foreach ($sortedDiscounts as $item) {
            $discount = $item['discount'];
            $userDiscount = $item['user_discount'];

            if ($discount->type === 'percentage') {
                if ($maxPercentageCap && ($totalPercentage + $discount->value) > $maxPercentageCap) {
                    continue;
                }

                $discountAmount = $this->round(($currentAmount * $discount->value) / 100);
                $totalPercentage += $discount->value;
            } else {
                $discountAmount = min($discount->value, $currentAmount);
            }

            $currentAmount -= $discountAmount;
            $totalDiscountAmount += $discountAmount;

            $userDiscount->increment('usage_count');
            $discount->increment('current_uses');

            DiscountAudit::create([
                'user_id' => $user->id,
                'discount_id' => $discount->id,
                'action' => 'applied',
                'original_amount' => $originalAmount,
                'discount_amount' => $discountAmount,
                'final_amount' => $currentAmount,
                'created_at' => now(),
            ]);

            event(new DiscountApplied($user, $discount, $originalAmount, $discountAmount, $currentAmount));

            $appliedDiscounts[] = [
                'discount_id' => $discount->id,
                'code' => $discount->code,
                'type' => $discount->type,
                'value' => $discount->value,
                'discount_amount' => $discountAmount,
            ];

            if ($currentAmount <= 0) {
                break;
            }
        }

        return [
            'original_amount' => $this->round($originalAmount),
            'discount_amount' => $this->round($totalDiscountAmount),
            'final_amount' => $this->round(max(0, $currentAmount)),
            'applied_discounts' => $appliedDiscounts,
        ];
    }

    private function round(float $value): float
    {
        $precision = config('user-discounts.rounding_precision', 2);
        $mode = config('user-discounts.rounding_mode', 'half_up');

        return match ($mode) {
            'up' => ceil($value * pow(10, $precision)) / pow(10, $precision),
            'down' => floor($value * pow(10, $precision)) / pow(10, $precision),
            'half_down' => round($value, $precision, PHP_ROUND_HALF_DOWN),
            default => round($value, $precision, PHP_ROUND_HALF_UP),
        };
    }
}
