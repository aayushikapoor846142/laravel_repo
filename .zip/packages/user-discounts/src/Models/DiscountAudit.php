<?php

namespace YourVendor\UserDiscounts\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DiscountAudit extends Model
{
    const UPDATED_AT = null;

    protected $fillable = [
        'user_id',
        'discount_id',
        'action',
        'original_amount',
        'discount_amount',
        'final_amount',
        'metadata',
    ];

    protected $casts = [
        'original_amount' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'final_amount' => 'decimal:2',
        'metadata' => 'array',
        'created_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(config('auth.providers.users.model', 'App\Models\User'));
    }

    public function discount(): BelongsTo
    {
        return $this->belongsTo(Discount::class);
    }
}
