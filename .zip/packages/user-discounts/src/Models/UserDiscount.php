<?php

namespace YourVendor\UserDiscounts\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserDiscount extends Model
{
    protected $fillable = [
        'user_id',
        'discount_id',
        'usage_count',
        'assigned_at',
        'revoked_at',
    ];

    protected $casts = [
        'usage_count' => 'integer',
        'assigned_at' => 'datetime',
        'revoked_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(config('auth.providers.users.model', 'App\Models\User'));
    }

    public function discount(): BelongsTo
    {
        return $this->belongsTo(Discount::class);
    }

    public function isRevoked(): bool
    {
        return $this->revoked_at !== null;
    }

    public function canUse(): bool
    {
        if ($this->isRevoked()) {
            return false;
        }

        $discount = $this->discount;

        if (!$discount->isActive()) {
            return false;
        }

        if ($discount->max_uses_per_user && $this->usage_count >= $discount->max_uses_per_user) {
            return false;
        }

        return true;
    }
}
