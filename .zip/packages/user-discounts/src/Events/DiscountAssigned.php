<?php

namespace YourVendor\UserDiscounts\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use YourVendor\UserDiscounts\Models\Discount;

class DiscountAssigned
{
    use Dispatchable, SerializesModels;

    public function __construct(
        public $user,
        public Discount $discount
    ) {}
}
