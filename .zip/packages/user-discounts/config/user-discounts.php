<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Stacking Order
    |--------------------------------------------------------------------------
    |
    | Determines the order in which discounts are applied.
    | Options: 'percentage_first', 'fixed_first', 'highest_first'
    |
    */
    'stacking_order' => env('DISCOUNT_STACKING_ORDER', 'percentage_first'),

    /*
    |--------------------------------------------------------------------------
    | Maximum Percentage Cap
    |--------------------------------------------------------------------------
    |
    | The maximum total percentage discount that can be applied.
    | Set to null for no limit.
    |
    */
    'max_percentage_cap' => env('DISCOUNT_MAX_PERCENTAGE', 100),

    /*
    |--------------------------------------------------------------------------
    | Rounding Mode
    |--------------------------------------------------------------------------
    |
    | How to round discount amounts.
    | Options: 'up', 'down', 'half_up', 'half_down'
    |
    */
    'rounding_mode' => env('DISCOUNT_ROUNDING', 'half_up'),

    /*
    |--------------------------------------------------------------------------
    | Rounding Precision
    |--------------------------------------------------------------------------
    |
    | Number of decimal places for rounding.
    |
    */
    'rounding_precision' => env('DISCOUNT_PRECISION', 2),
];
