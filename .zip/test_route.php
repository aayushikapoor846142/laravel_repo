<?php

// Simple test to check if the route works
$url = 'http://localhost:8000/';

echo "Testing route: $url\n\n";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);

curl_close($ch);

echo "HTTP Code: $httpCode\n";

if ($error) {
    echo "Error: $error\n";
    echo "\nMake sure the server is running with: php artisan serve\n";
} else {
    if ($httpCode === 200) {
        echo "✓ Route is working!\n\n";
        echo "Response preview (first 500 chars):\n";
        echo substr($response, 0, 500) . "...\n";
    } else {
        echo "✗ Route returned error code: $httpCode\n";
        echo "\nResponse:\n";
        echo substr($response, 0, 1000) . "\n";
    }
}
