@extends('layouts.app')

@section('title', $product->name)

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="mb-6">
        <a href="{{ route('products.index') }}" class="text-blue-500 hover:text-blue-700">
            ← Back to Products
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="md:flex">
            <!-- Product Images -->
            <div class="md:w-1/2 p-6">
                @if($product->primaryImage)
                    <img src="{{ Storage::url($product->primaryImage->path) }}" 
                         alt="{{ $product->name }}" 
                         class="w-full rounded-lg mb-4">
                    
                    @if($product->images->count() > 1)
                        <div class="grid grid-cols-4 gap-2">
                            @foreach($product->images->where('variant', '256px') as $image)
                                <img src="{{ Storage::url($image->path) }}" 
                                     alt="{{ $product->name }}" 
                                     class="w-full rounded cursor-pointer hover:opacity-75">
                            @endforeach
                        </div>
                    @endif
                @else
                    <div class="w-full h-96 bg-gray-200 flex items-center justify-center rounded-lg">
                        <span class="text-gray-400 text-xl">No Image Available</span>
                    </div>
                @endif
            </div>

            <!-- Product Details -->
            <div class="md:w-1/2 p-6">
                <h1 class="text-3xl font-bold mb-4">{{ $product->name }}</h1>
                
                <div class="mb-6">
                    <span class="text-gray-600">SKU:</span>
                    <span class="font-semibold">{{ $product->sku }}</span>
                </div>

                <div class="mb-6">
                    <span class="text-3xl font-bold text-green-600">
                        ${{ number_format($product->price, 2) }}
                    </span>
                </div>

                <div class="mb-6">
                    <span class="text-gray-600">Stock:</span>
                    <span class="font-semibold {{ $product->stock > 0 ? 'text-green-600' : 'text-red-600' }}">
                        {{ $product->stock }} units
                    </span>
                </div>

                @if($product->description)
                    <div class="mb-6">
                        <h2 class="text-xl font-semibold mb-2">Description</h2>
                        <p class="text-gray-700">{{ $product->description }}</p>
                    </div>
                @endif

                <div class="mb-6">
                    <h2 class="text-xl font-semibold mb-2">Image Variants</h2>
                    <div class="space-y-2">
                        @foreach($product->images->groupBy('variant') as $variant => $images)
                            <div class="flex items-center">
                                <span class="text-gray-600 w-24">{{ $variant }}:</span>
                                <span class="text-gray-800">{{ $images->count() }} image(s)</span>
                            </div>
                        @endforeach
                    </div>
                </div>

                <div class="text-sm text-gray-500">
                    <p>Created: {{ $product->created_at->format('M d, Y H:i') }}</p>
                    <p>Updated: {{ $product->updated_at->format('M d, Y H:i') }}</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
