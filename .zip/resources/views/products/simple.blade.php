<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
</head>
<body>
    <h1>Products List</h1>
    <p>Total products: {{ $products->total() }}</p>
    
    @foreach($products as $product)
        <div style="border: 1px solid #ccc; padding: 10px; margin: 10px 0;">
            <h2>{{ $product->name }}</h2>
            <p>SKU: {{ $product->sku }}</p>
            <p>Price: ${{ $product->price }}</p>
            <p>Stock: {{ $product->stock }}</p>
        </div>
    @endforeach
    
    {{ $products->links() }}
</body>
</html>
